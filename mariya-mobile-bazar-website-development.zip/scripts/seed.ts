import "dotenv/config";
import { db } from "../src/db";
import { users, categories, products, productImages, storeSettings } from "../src/db/schema";
import { eq } from "drizzle-orm";
import { hashPassword } from "../src/lib/auth";

async function main() {
  // store settings
  const existingSettings = await db.select().from(storeSettings).limit(1);
  if (!existingSettings.length) {
    await db.insert(storeSettings).values({});
  }

  // admin
  const adminEmail = process.env.INITIAL_ADMIN_EMAIL || "admin@mariyamobilebazar.com";
  const adminPassword = process.env.INITIAL_ADMIN_PASSWORD || "Admin@12345";
  const [existingAdmin] = await db.select().from(users).where(eq(users.email, adminEmail.toLowerCase())).limit(1);
  if (!existingAdmin) {
    await db.insert(users).values({
      name: "Store Admin",
      email: adminEmail.toLowerCase(),
      passwordHash: await hashPassword(adminPassword),
      role: "admin",
    });
    console.log("Admin created:", adminEmail);
  } else {
    console.log("Admin already exists:", adminEmail);
  }

  // categories
  const categoryData = [
    { name: "iPhone", slug: "iphone", sortOrder: 1 },
    { name: "Samsung", slug: "samsung", sortOrder: 2 },
    { name: "Xiaomi", slug: "xiaomi", sortOrder: 3 },
    { name: "Vivo", slug: "vivo", sortOrder: 4 },
    { name: "Oppo", slug: "oppo", sortOrder: 5 },
    { name: "Realme", slug: "realme", sortOrder: 6 },
    { name: "Accessories", slug: "accessories", sortOrder: 7 },
  ];
  for (const c of categoryData) {
    const [existing] = await db.select().from(categories).where(eq(categories.slug, c.slug)).limit(1);
    if (!existing) await db.insert(categories).values(c);
  }

  const allCategories = await db.select().from(categories);
  const catBySlug = new Map(allCategories.map((c) => [c.slug, c.id]));

  // sample products
  const sampleProducts = [
    {
      name: "iPhone 15 128GB",
      brand: "Apple",
      category: "iphone",
      price: 115000,
      discountPrice: 109999,
      stock: 8,
      ram: "6GB",
      storage: "128GB",
      color: "Black",
      image: "https://placehold.co/600x600?text=iPhone+15",
    },
    {
      name: "Samsung Galaxy S24 256GB",
      brand: "Samsung",
      category: "samsung",
      price: 98000,
      discountPrice: 92500,
      stock: 10,
      ram: "8GB",
      storage: "256GB",
      color: "Gray",
      image: "https://placehold.co/600x600?text=Galaxy+S24",
    },
    {
      name: "Xiaomi 14 512GB",
      brand: "Xiaomi",
      category: "xiaomi",
      price: 72000,
      discountPrice: 68999,
      stock: 12,
      ram: "12GB",
      storage: "512GB",
      color: "White",
      image: "https://placehold.co/600x600?text=Xiaomi+14",
    },
    {
      name: "Vivo V30 256GB",
      brand: "Vivo",
      category: "vivo",
      price: 45000,
      discountPrice: 41999,
      stock: 15,
      ram: "8GB",
      storage: "256GB",
      color: "Blue",
      image: "https://placehold.co/600x600?text=Vivo+V30",
    },
    {
      name: "Oppo Reno 11 256GB",
      brand: "Oppo",
      category: "oppo",
      price: 42000,
      discountPrice: null,
      stock: 9,
      ram: "8GB",
      storage: "256GB",
      color: "Green",
      image: "https://placehold.co/600x600?text=Oppo+Reno+11",
    },
    {
      name: "Realme 12 Pro+ 256GB",
      brand: "Realme",
      category: "realme",
      price: 38000,
      discountPrice: 35999,
      stock: 14,
      ram: "8GB",
      storage: "256GB",
      color: "Gold",
      image: "https://placehold.co/600x600?text=Realme+12+Pro+",
    },
    {
      name: "20W Fast Charger",
      brand: "Accessories",
      category: "accessories",
      price: 800,
      discountPrice: 650,
      stock: 50,
      ram: null,
      storage: null,
      color: "White",
      image: "https://placehold.co/600x600?text=Charger",
    },
    {
      name: "Premium Phone Case",
      brand: "Accessories",
      category: "accessories",
      price: 500,
      discountPrice: null,
      stock: 80,
      ram: null,
      storage: null,
      color: "Black",
      image: "https://placehold.co/600x600?text=Phone+Case",
    },
  ];

  for (const p of sampleProducts) {
    const slug = p.name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
    const [existing] = await db.select().from(products).where(eq(products.slug, slug)).limit(1);
    if (existing) continue;
    const [product] = await db
      .insert(products)
      .values({
        name: p.name,
        slug,
        brand: p.brand,
        categoryId: catBySlug.get(p.category) || null,
        description: `${p.name} available at Mariya Mobile Bazar, Benapole.`,
        warranty: "Official warranty",
        condition: "new",
        ram: p.ram,
        storage: p.storage,
        color: p.color,
        price: p.price,
        discountPrice: p.discountPrice,
        stock: p.stock,
        isPublished: true,
        isFeatured: true,
      })
      .returning();
    await db.insert(productImages).values({ productId: product.id, url: p.image, sortOrder: 0 });
  }

  console.log("Seed complete");
  process.exit(0);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
