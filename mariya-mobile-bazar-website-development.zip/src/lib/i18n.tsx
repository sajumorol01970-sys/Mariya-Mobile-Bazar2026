"use client";

import React, { createContext, useContext, useEffect, useState } from "react";

export type Lang = "bn" | "en";

const translations = {
  bn: {
    home: "হোম",
    smartphones: "স্মার্টফোন",
    accessories: "এক্সেসরিজ",
    offers: "অফার",
    trackOrder: "অর্ডার ট্র্যাক",
    contact: "যোগাযোগ",
    login: "লগইন",
    register: "রেজিস্ট্রেশন",
    search: "ফোন ও এক্সেসরিজ খুঁজুন",
    buyNow: "এখনই কিনুন",
    addToCart: "কার্টে যোগ করুন",
    price: "দাম",
    stock: "স্টক",
    available: "স্টকে আছে",
    outOfStock: "স্টক শেষ",
    cart: "কার্ট",
    checkout: "চেকআউট",
    total: "মোট",
    delivery: "ডেলিভারি চার্জ",
    payable: "পরিশোধযোগ্য",
    cod: "ক্যাশ অন ডেলিভারি",
    orderNumber: "অর্ডার নম্বর",
    track: "ট্র্যাক করুন",
    whatsapp: "WhatsApp",
    admin: "অ্যাডমিন",
    logout: "লগআউট",
    language: "ভাষা",
  },
  en: {
    home: "Home",
    smartphones: "Smartphones",
    accessories: "Accessories",
    offers: "Offers",
    trackOrder: "Track Order",
    contact: "Contact",
    login: "Login",
    register: "Register",
    search: "Search phones and accessories",
    buyNow: "Buy Now",
    addToCart: "Add to Cart",
    price: "Price",
    stock: "Stock",
    available: "In stock",
    outOfStock: "Out of stock",
    cart: "Cart",
    checkout: "Checkout",
    total: "Total",
    delivery: "Delivery charge",
    payable: "Payable",
    cod: "Cash on Delivery",
    orderNumber: "Order number",
    track: "Track",
    whatsapp: "WhatsApp",
    admin: "Admin",
    logout: "Logout",
    language: "Language",
  },
} as const;

type Dictionary = (typeof translations)[Lang];

const LanguageContext = createContext<{
  lang: Lang;
  setLang: (lang: Lang) => void;
  t: Dictionary;
} | null>(null);

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [lang, setLangState] = useState<Lang>("bn");
  useEffect(() => {
    const stored = window.localStorage.getItem("mmb_lang");
    if (stored === "bn" || stored === "en") setLangState(stored);
  }, []);
  const setLang = (next: Lang) => {
    setLangState(next);
    window.localStorage.setItem("mmb_lang", next);
    document.documentElement.lang = next === "bn" ? "bn" : "en";
  };
  return (
    <LanguageContext.Provider value={{ lang, setLang, t: translations[lang] }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const ctx = useContext(LanguageContext);
  if (!ctx) throw new Error("LanguageProvider missing");
  return ctx;
}
