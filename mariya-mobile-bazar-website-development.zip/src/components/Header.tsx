"use client";

import Link from "next/link";
import { useLanguage } from "@/lib/i18n";
import { useState } from "react";

export default function Header() {
  const { t, lang, setLang } = useLanguage();
  const [open, setOpen] = useState(false);
  const nav = [
    { href: "/", label: t.home },
    { href: "/products?category=smartphones", label: t.smartphones },
    { href: "/products?category=accessories", label: t.accessories },
    { href: "/offers", label: t.offers },
    { href: "/track", label: t.trackOrder },
    { href: "/contact", label: t.contact },
  ];

  return (
    <header className="sticky top-0 z-40 border-b border-red-100 bg-white/95 backdrop-blur">
      <div className="mx-auto flex max-w-7xl items-center gap-4 px-4 py-3">
        <Link href="/" className="flex items-center gap-2">
          <span className="grid h-10 w-10 place-items-center rounded-xl bg-red-600 text-lg font-bold text-white">
            M
          </span>
          <span className="text-lg font-bold tracking-tight">
            Mariya Mobile Bazar
          </span>
        </Link>

        <form action="/products" className="hidden flex-1 md:flex">
          <input
            name="q"
            placeholder={t.search}
            className="w-full rounded-full border border-gray-300 px-4 py-2 outline-none focus:border-red-600"
          />
        </form>

        <nav className="hidden items-center gap-4 lg:flex">
          {nav.map((item) => (
            <Link key={item.href} href={item.href} className="text-sm font-medium hover:text-red-600">
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="ml-auto flex items-center gap-2">
          <button
            onClick={() => setLang(lang === "bn" ? "en" : "bn")}
            className="rounded-full border border-gray-300 px-3 py-1 text-sm"
          >
            {lang === "bn" ? "EN" : "বাংলা"}
          </button>
          <Link href="/login" className="rounded-full bg-red-600 px-4 py-2 text-sm font-semibold text-white">
            {t.login}
          </Link>
          <button
            className="lg:hidden rounded-full border border-gray-300 px-3 py-1"
            onClick={() => setOpen(!open)}
            aria-label="Menu"
          >
            ☰
          </button>
        </div>
      </div>

      {open && (
        <div className="border-t border-gray-100 px-4 py-3 lg:hidden">
          <form action="/products" className="mb-3">
            <input
              name="q"
              placeholder={t.search}
              className="w-full rounded-full border border-gray-300 px-4 py-2"
            />
          </form>
          <div className="flex flex-col gap-2">
            {nav.map((item) => (
              <Link key={item.href} href={item.href} onClick={() => setOpen(false)} className="py-1">
                {item.label}
              </Link>
            ))}
          </div>
        </div>
      )}
    </header>
  );
}
