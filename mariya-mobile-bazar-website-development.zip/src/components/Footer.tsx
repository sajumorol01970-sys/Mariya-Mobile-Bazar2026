import Link from "next/link";

export default function Footer() {
  return (
    <footer className="mt-16 border-t border-gray-200 bg-gray-50">
      <div className="mx-auto grid max-w-7xl gap-8 px-4 py-10 md:grid-cols-4">
        <div>
          <h3 className="text-lg font-bold">Mariya Mobile Bazar</h3>
          <p className="mt-2 text-sm text-gray-600">
            Benapole, Jessore, Bangladesh
          </p>
          <p className="text-sm text-gray-600">+8801700000000</p>
        </div>
        <div>
          <h4 className="font-semibold">Shop</h4>
          <ul className="mt-2 space-y-1 text-sm text-gray-600">
            <li><Link href="/products">Smartphones</Link></li>
            <li><Link href="/products?category=accessories">Accessories</Link></li>
            <li><Link href="/offers">Offers</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="font-semibold">Support</h4>
          <ul className="mt-2 space-y-1 text-sm text-gray-600">
            <li><Link href="/track">Order Tracking</Link></li>
            <li><Link href="/contact">Contact</Link></li>
            <li><Link href="/privacy">Privacy Policy</Link></li>
            <li><Link href="/terms">Terms</Link></li>
            <li><Link href="/returns">Return Policy</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="font-semibold">Social</h4>
          <div className="mt-2 flex gap-3 text-sm text-gray-600">
            <a href="https://facebook.com" target="_blank" rel="noreferrer">Facebook</a>
          </div>
        </div>
      </div>
      <div className="border-t border-gray-200 py-4 text-center text-xs text-gray-500">
        © 2026 Mariya Mobile Bazar. All rights reserved.
      </div>
    </footer>
  );
}
