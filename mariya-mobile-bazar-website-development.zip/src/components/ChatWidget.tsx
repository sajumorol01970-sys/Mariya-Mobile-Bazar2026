"use client";

import { useState } from "react";

type Msg = { role: "user" | "assistant"; content: string };

export default function ChatWidget() {
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState<Msg[]>([
    { role: "assistant", content: "আসসালামু আলাইকুম! আমি Mariya Mobile Bazar-এর সহায়তা বট। কীভাবে সাহায্য করতে পারি?" },
  ]);
  const [loading, setLoading] = useState(false);

  async function send() {
    if (!input.trim() || loading) return;
    const text = input.trim();
    setInput("");
    setMessages((m) => [...m, { role: "user", content: text }]);
    setLoading(true);
    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: text, history: messages }),
      });
      const data = await res.json();
      setMessages((m) => [...m, { role: "assistant", content: data.reply || "দুঃখিত, উত্তর পাওয়া যায়নি।" }]);
    } catch {
      setMessages((m) => [...m, { role: "assistant", content: "সংযোগ সমস্যা। WhatsApp-এ যোগাযোগ করুন।" }]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <button
        onClick={() => setOpen(!open)}
        className="fixed bottom-4 right-4 z-50 grid h-14 w-14 place-items-center rounded-full bg-red-600 text-2xl text-white shadow-xl"
        aria-label="Chat"
      >
        🤖
      </button>
      {open && (
        <div className="fixed bottom-20 right-4 z-50 flex h-[420px] w-[340px] max-w-[calc(100vw-2rem)] flex-col overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-2xl">
          <div className="bg-red-600 px-4 py-3 text-white">
            <p className="font-semibold">Mariya Mobile Bazar Support</p>
          </div>
          <div className="flex-1 space-y-3 overflow-y-auto p-3 text-sm">
            {messages.map((m, i) => (
              <div
                key={i}
                className={`max-w-[85%] rounded-2xl px-3 py-2 ${
                  m.role === "user" ? "ml-auto bg-red-600 text-white" : "bg-gray-100"
                }`}
              >
                {m.content}
              </div>
            ))}
            {loading && <div className="bg-gray-100 max-w-[85%] rounded-2xl px-3 py-2">...</div>}
          </div>
          <div className="flex gap-2 border-t p-3">
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && send()}
              placeholder="মেসেজ লিখুন..."
              className="flex-1 rounded-full border border-gray-300 px-3 py-2 text-sm"
            />
            <button onClick={send} className="rounded-full bg-red-600 px-4 py-2 text-sm text-white">
              Send
            </button>
          </div>
        </div>
      )}
    </>
  );
}
