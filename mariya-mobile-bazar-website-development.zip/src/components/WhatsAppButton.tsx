"use client";

import { useEffect, useState } from "react";

export default function WhatsAppButton() {
  const [phone, setPhone] = useState("8801700000000");

  useEffect(() => {
    fetch("/api/settings")
      .then((r) => r.json())
      .then((d) => {
        if (d?.whatsapp) setPhone(String(d.whatsapp).replace(/\D/g, ""));
      })
      .catch(() => {});
  }, []);

  return (
    <a
      href={`https://wa.me/${phone}`}
      target="_blank"
      rel="noreferrer"
      className="fixed bottom-24 right-4 z-40 grid h-12 w-12 place-items-center rounded-full bg-green-500 text-xl text-white shadow-lg transition hover:scale-110"
      aria-label="WhatsApp"
    >
      💬
    </a>
  );
}
