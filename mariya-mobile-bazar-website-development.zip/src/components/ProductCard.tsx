import Link from "next/link";
import { formatBDT, discountPercent } from "@/lib/utils";

type Product = {
  id: string;
  name: string;
  slug: string;
  brand: string;
  price: number;
  discountPrice: number | null;
  stock: number;
  color?: string | null;
  imageUrl?: string | null;
};

export default function ProductCard({ product }: { product: Product }) {
  const percent = discountPercent(product.price, product.discountPrice);
  const finalPrice = product.discountPrice ?? product.price;

  return (
    <article className="group overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-sm transition hover:-translate-y-1 hover:shadow-lg">
      <Link href={`/products/${product.slug}`}>
        <div className="aspect-square overflow-hidden bg-gray-100">
          {product.imageUrl ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={product.imageUrl}
              alt={product.name}
              className="h-full w-full object-cover transition group-hover:scale-105"
            />
          ) : (
            <div className="grid h-full place-items-center text-gray-400">No image</div>
          )}
        </div>
      </Link>
      <div className="p-4">
        <p className="text-xs font-semibold uppercase tracking-wide text-red-600">{product.brand}</p>
        <Link href={`/products/${product.slug}`}>
          <h3 className="mt-1 line-clamp-2 text-sm font-semibold">{product.name}</h3>
        </Link>
        <div className="mt-2 flex items-center gap-2">
          <span className="text-base font-bold">{formatBDT(finalPrice)}</span>
          {product.discountPrice && (
            <span className="text-xs text-gray-400 line-through">{formatBDT(product.price)}</span>
          )}
          {percent > 0 && (
            <span className="rounded-full bg-red-100 px-2 py-0.5 text-xs font-semibold text-red-700">
              -{percent}%
            </span>
          )}
        </div>
        {product.color && <p className="mt-1 text-xs text-gray-500">Color: {product.color}</p>}
        <p className="mt-1 text-xs text-gray-500">
          {product.stock > 0 ? `Stock: ${product.stock}` : "Out of stock"}
        </p>
        <Link
          href={`/checkout?productId=${product.id}&qty=1`}
          className="mt-3 block rounded-full bg-red-600 px-4 py-2 text-center text-sm font-semibold text-white"
        >
          অর্ডার নাও
        </Link>
      </div>
    </article>
  );
}
