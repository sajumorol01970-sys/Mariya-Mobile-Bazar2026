"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

type Product = {
  id: string;
  name: string;
  slug: string;
  price: number;
  discountPrice: number | null;
  stock: number;
};

export default function ProductActions({ product }: { product: Product }) {
  const router = useRouter();
  const [qty, setQty] = useState(1);
  const [wishlisted, setWishlisted] = useState(false);

  function addToCart() {
    const cart = JSON.parse(localStorage.getItem("mmb_cart") || "[]");
    const existing = cart.find((i: any) => i.productId === product.id);
    if (existing) existing.quantity += qty;
    else cart.push({ productId: product.id, name: product.name, slug: product.slug, price: product.discountPrice ?? product.price, quantity: qty });
    localStorage.setItem("mmb_cart", JSON.stringify(cart));
    alert("Added to cart");
  }

  async function toggleWishlist() {
    const res = await fetch("/api/wishlist", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ productId: product.id }),
    });
    if (res.ok) {
      const data = await res.json();
      setWishlisted(data.wishlisted);
    } else {
      router.push("/login");
    }
  }

  function buyNow() {
    addToCart();
    router.push("/cart");
  }

  return (
    <div className="mt-4 flex flex-wrap items-center gap-3">
      <div className="flex items-center rounded-full border border-gray-300">
        <button onClick={() => setQty(Math.max(1, qty - 1))} className="px-3 py-2">-</button>
        <span className="px-3">{qty}</span>
        <button onClick={() => setQty(Math.min(product.stock || 1, qty + 1))} className="px-3 py-2">+</button>
      </div>
      <button
        onClick={addToCart}
        disabled={product.stock <= 0}
        className="rounded-full border border-red-600 px-5 py-2 font-semibold text-red-600 disabled:opacity-50"
      >
        Add to Cart
      </button>
      <button
        onClick={buyNow}
        disabled={product.stock <= 0}
        className="rounded-full bg-red-600 px-5 py-2 font-semibold text-white disabled:opacity-50"
      >
        Buy Now
      </button>
      <button onClick={toggleWishlist} className="rounded-full border border-gray-300 px-4 py-2">
        {wishlisted ? "♥" : "♡"} Wishlist
      </button>
    </div>
  );
}
