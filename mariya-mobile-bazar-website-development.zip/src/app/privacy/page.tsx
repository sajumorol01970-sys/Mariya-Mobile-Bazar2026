export default function PrivacyPage() {
  return (
    <div className="mx-auto max-w-3xl px-4 py-8 prose">
      <h1>Privacy Policy</h1>
      <p>We protect customer information and use it only for order fulfillment and support.</p>
    </div>
  );
}