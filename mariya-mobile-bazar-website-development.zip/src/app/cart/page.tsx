"use client";

import Link from "next/link";
import { useEffect, useState } from "react";

type CartItem = {
  productId: string;
  name: string;
  slug: string;
  price: number;
  quantity: number;
};

export default function CartPage() {
  const [items, setItems] = useState<CartItem[]>([]);

  useEffect(() => {
    setItems(JSON.parse(localStorage.getItem("mmb_cart") || "[]"));
  }, []);

  function updateQty(id: string, qty: number) {
    const next = items.map((i) => (i.productId === id ? { ...i, quantity: Math.max(1, qty) } : i));
    setItems(next);
    localStorage.setItem("mmb_cart", JSON.stringify(next));
  }

  function remove(id: string) {
    const next = items.filter((i) => i.productId !== id);
    setItems(next);
    localStorage.setItem("mmb_cart", JSON.stringify(next));
  }

  const subtotal = items.reduce((sum, i) => sum + i.price * i.quantity, 0);

  return (
    <div className="mx-auto max-w-4xl px-4 py-8">
      <h1 className="text-2xl font-bold">Cart</h1>
      {items.length === 0 ? (
        <p className="mt-6 text-gray-500">Your cart is empty.</p>
      ) : (
        <>
          <div className="mt-6 space-y-4">
            {items.map((item) => (
              <div key={item.productId} className="flex items-center justify-between rounded-2xl border border-gray-200 bg-white p-4">
                <div>
                  <Link href={`/products/${item.slug}`} className="font-semibold">{item.name}</Link>
                  <p className="text-sm text-gray-500">{item.price} BDT</p>
                </div>
                <div className="flex items-center gap-3">
                  <button onClick={() => updateQty(item.productId, item.quantity - 1)} className="rounded-full border px-3 py-1">-</button>
                  <span>{item.quantity}</span>
                  <button onClick={() => updateQty(item.productId, item.quantity + 1)} className="rounded-full border px-3 py-1">+</button>
                  <button onClick={() => remove(item.productId)} className="text-red-600">Remove</button>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-6 rounded-2xl border border-gray-200 bg-gray-50 p-4">
            <p className="text-lg font-bold">Subtotal: {subtotal} BDT</p>
            <Link href="/checkout" className="mt-4 inline-block rounded-full bg-red-600 px-6 py-3 font-semibold text-white">
              Checkout
            </Link>
          </div>
        </>
      )}
    </div>
  );
}
