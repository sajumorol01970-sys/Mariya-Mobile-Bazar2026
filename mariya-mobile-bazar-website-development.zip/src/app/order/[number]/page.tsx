import { db } from "@/db";
import { orders, orderItems } from "@/db/schema";
import { eq } from "drizzle-orm";
import Link from "next/link";

export const dynamic = "force-dynamic";

export default async function OrderConfirmationPage({
  params,
  searchParams,
}: {
  params: Promise<{ number: string }>;
  searchParams: Promise<{ phone?: string }>;
}) {
  const { number } = await params;
  const sp = await searchParams;
  const phone = sp.phone;

  let order = null as any;
  let items: any[] = [];
  if (phone) {
    const [o] = await db.select().from(orders).where(eq(orders.orderNumber, number)).limit(1);
    if (o && o.phone === phone) {
      order = o;
      items = await db.select().from(orderItems).where(eq(orderItems.orderId, o.id));
    }
  }

  return (
    <div className="mx-auto max-w-2xl px-4 py-8">
      <div className="rounded-2xl border border-green-200 bg-green-50 p-6 text-center">
        <h1 className="text-2xl font-bold text-green-700">Order Placed Successfully</h1>
        <p className="mt-2 text-sm">Your order number is:</p>
        <p className="mt-1 text-xl font-bold">{number}</p>
      </div>

      {order ? (
        <div className="mt-6 rounded-2xl border border-gray-200 bg-white p-6">
          <p><strong>Status:</strong> {order.status}</p>
          <p><strong>Total:</strong> {order.total} BDT</p>
          <p><strong>Delivery:</strong> {order.deliveryCharge} BDT</p>
          <ul className="mt-4 space-y-2 text-sm">
            {items.map((i) => (
              <li key={i.id}>{i.productName} × {i.quantity} = {i.lineTotal} BDT</li>
            ))}
          </ul>
        </div>
      ) : (
        <p className="mt-6 text-sm text-gray-600">
          Save your order number and phone number to track your order.
        </p>
      )}

      <div className="mt-6 flex flex-wrap gap-3">
        <Link href={`/track?orderNumber=${number}`} className="rounded-full bg-red-600 px-5 py-2 font-semibold text-white">
          Track Order
        </Link>
      </div>
    </div>
  );
}
