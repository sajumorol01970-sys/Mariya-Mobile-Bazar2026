"use client";

import { useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense } from "react";

type CartItem = { productId: string; quantity: number; name?: string; price?: number };

function CheckoutInner() {
  const router = useRouter();
  const sp = useSearchParams();
  const productId = sp.get("productId");
  const qtyParam = Number(sp.get("qty") || 1);

  const [items, setItems] = useState<CartItem[]>([]);
  const [product, setProduct] = useState<any>(null);
  const [settings, setSettings] = useState<any>(null);
  const [form, setForm] = useState({
    customerName: "",
    phone: "",
    email: "",
    address: "",
    district: "",
    notes: "",
  });
  const [quantity, setQuantity] = useState(qtyParam > 0 ? qtyParam : 1);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (productId) {
      fetch(`/api/products/${productId}`).then((r) => r.json()).then((d) => setProduct(d.product));
      setItems([{ productId, quantity: qtyParam > 0 ? qtyParam : 1 }]);
    } else {
      const cart = JSON.parse(localStorage.getItem("mmb_cart") || "[]");
      setItems(cart.map((i: any) => ({ productId: i.productId, quantity: i.quantity, name: i.name, price: i.price })));
    }
    fetch("/api/settings").then((r) => r.json()).then(setSettings);
  }, [productId, qtyParam]);

  useEffect(() => {
    if (productId) {
      setItems([{ productId, quantity }]);
    }
  }, [quantity, productId]);

  const unitPrice = product ? (product.discountPrice ?? product.price) : 0;
  const subtotal = productId ? unitPrice * quantity : items.reduce((s, i) => s + (i.price || 0) * i.quantity, 0);
  const deliveryCharge = settings
    ? (form.district.toLowerCase().includes("dhaka") || form.district.toLowerCase().includes("ঢাকা")
        ? settings.insideDeliveryCharge
        : settings.outsideDeliveryCharge)
    : 0;
  const advanceEnabled = !!settings?.advanceChargeEnabled;
  const advanceCharge = advanceEnabled ? settings?.advanceCharge || 0 : 0;
  const total = subtotal + (deliveryCharge || 0);
  const remaining = total - advanceCharge;

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      const orderItems = productId
        ? [{ productId, quantity }]
        : items.map((i) => ({ productId: i.productId, quantity: i.quantity }));

      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, items: orderItems }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Checkout failed");
      if (!productId) localStorage.removeItem("mmb_cart");
      router.push(`/payment/${data.orderNumber}?phone=${encodeURIComponent(form.phone)}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Checkout failed");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="mx-auto max-w-2xl px-4 py-8">
      <h1 className="text-2xl font-bold">অর্ডার ফর্ম</h1>

      {product && (
        <div className="mt-4 rounded-2xl border border-gray-200 bg-gray-50 p-4">
          <p className="font-semibold">{product.name}</p>
          <p className="text-sm text-gray-600">Price: {unitPrice} BDT</p>
          {product.color && <p className="text-sm text-gray-600">Color: {product.color}</p>}
          <div className="mt-2 flex items-center gap-2">
            <span>Quantity:</span>
            <button type="button" onClick={() => setQuantity(Math.max(1, quantity - 1))} className="rounded-full border px-3 py-1">-</button>
            <span>{quantity}</span>
            <button type="button" onClick={() => setQuantity(quantity + 1)} className="rounded-full border px-3 py-1">+</button>
          </div>
        </div>
      )}

      {advanceEnabled && (
        <div className="mt-4 rounded-2xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-900">
          {settings?.advanceChargeLabel || "IMEI রেজিস্ট্রেশন / প্রযোজ্য সরকারি ফি"}: {advanceCharge} টাকা অগ্রিম প্রদান করতে হবে। এই অর্থ অর্ডারের মোট মূল্যের সঙ্গে সমন্বয় করা হবে।
        </div>
      )}

      <form onSubmit={submit} className="mt-6 space-y-4 rounded-2xl border border-gray-200 bg-white p-6">
        <input required placeholder="Customer full name" value={form.customerName} onChange={(e) => setForm({ ...form, customerName: e.target.value })} className="w-full rounded-lg border border-gray-300 px-3 py-2" />
        <input required placeholder="Mobile phone number" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} className="w-full rounded-lg border border-gray-300 px-3 py-2" />
        <input type="email" placeholder="Email (optional)" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="w-full rounded-lg border border-gray-300 px-3 py-2" />
        <textarea required placeholder="Full delivery address" value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} className="w-full rounded-lg border border-gray-300 px-3 py-2" />
        <input required placeholder="District" value={form.district} onChange={(e) => setForm({ ...form, district: e.target.value })} className="w-full rounded-lg border border-gray-300 px-3 py-2" />
        <textarea placeholder="Notes (optional)" value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} className="w-full rounded-lg border border-gray-300 px-3 py-2" />

        <div className="rounded-xl bg-gray-50 p-4 text-sm">
          <p>Product subtotal: {subtotal} BDT</p>
          <p>Delivery charge: {deliveryCharge || 0} BDT</p>
          {advanceEnabled && <p>Advance payment: {advanceCharge} BDT</p>}
          <p className="font-bold">Remaining balance: {remaining} BDT</p>
        </div>

        {error && <p className="text-sm text-red-600">{error}</p>}
        <button disabled={loading || items.length === 0} className="w-full rounded-full bg-red-600 py-3 font-semibold text-white disabled:opacity-50">
          {loading ? "Processing..." : "কনফার্ম করুন"}
        </button>
      </form>
    </div>
  );
}

export default function CheckoutPage() {
  return (
    <Suspense fallback={<div className="p-8">Loading...</div>}>
      <CheckoutInner />
    </Suspense>
  );
}
