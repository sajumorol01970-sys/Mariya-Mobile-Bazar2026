export default function ReturnsPage() {
  return (
    <div className="mx-auto max-w-3xl px-4 py-8 prose">
      <h1>Return Policy</h1>
      <p>Returns are handled according to product condition and store policy. Contact the store for assistance.</p>
    </div>
  );
}