"use client";

import { useEffect, useState } from "react";
import Link from "next/link";

export default function AdminDashboard() {
  const [stats, setStats] = useState<any>(null);

  useEffect(() => {
    fetch("/api/admin/dashboard").then((r) => r.json()).then(setStats);
  }, []);

  if (!stats) return <div className="p-8">Loading...</div>;

  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <h1 className="text-2xl font-bold">Admin Dashboard</h1>
      <div className="mt-6 grid gap-4 md:grid-cols-5">
        {[
          { label: "Total Orders", value: stats.totalOrders },
          { label: "Total Sales", value: stats.totalSales + " BDT" },
          { label: "Products", value: stats.totalProducts },
          { label: "Customers", value: stats.totalCustomers },
          { label: "Low Stock", value: stats.lowStock },
        ].map((s) => (
          <div key={s.label} className="rounded-2xl border border-gray-200 bg-white p-5 shadow-sm">
            <p className="text-sm text-gray-500">{s.label}</p>
            <p className="mt-1 text-2xl font-bold">{s.value}</p>
          </div>
        ))}
      </div>

      <div className="mt-8 grid gap-3 md:grid-cols-3">
        {[
          { href: "/admin/products", label: "Manage Products" },
          { href: "/admin/orders", label: "Manage Orders" },
          { href: "/admin/payments", label: "Payment Verification" },
          { href: "/admin/categories", label: "Categories" },
          { href: "/admin/banners", label: "Banners" },
          { href: "/admin/reviews", label: "Reviews" },
          { href: "/admin/settings", label: "Settings" },
        ].map((l) => (
          <Link key={l.href} href={l.href} className="rounded-2xl border border-gray-200 bg-white p-4 font-semibold hover:border-red-300">
            {l.label}
          </Link>
        ))}
      </div>

      <section className="mt-8">
        <h2 className="text-xl font-bold">Recent Orders</h2>
        <div className="mt-3 space-y-2">
          {stats.recentOrders?.map((o: any) => (
            <div key={o.id} className="rounded-xl border border-gray-200 bg-white p-3 text-sm">
              {o.orderNumber} - {o.customerName} - {o.total} BDT - {o.status}
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
