"use client";

import { useEffect, useState } from "react";

export default function AdminPaymentsPage() {
  const [payments, setPayments] = useState<any[]>([]);

  async function load() {
    const res = await fetch("/api/admin/payments");
    const data = await res.json();
    setPayments(data.payments || []);
  }

  useEffect(() => {
    load();
  }, []);

  async function action(id: string, act: "verify" | "reject") {
    const reason = act === "reject" ? prompt("Rejection reason") || "" : undefined;
    await fetch(`/api/admin/payments/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: act, reason }),
    });
    await load();
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <h1 className="text-2xl font-bold">Payment Verification</h1>
      <div className="mt-6 space-y-4">
        {payments.map((p) => (
          <div key={p.id} className="rounded-2xl border border-gray-200 bg-white p-4">
            <p className="font-semibold">{p.provider} - {p.transactionId}</p>
            <p className="text-sm text-gray-600">Order: {p.order?.orderNumber} | Amount: {p.amount} BDT</p>
            <p className="text-sm text-gray-600">Sender: {p.senderPhone} | Status: {p.status}</p>
            {p.status === "pending_verification" && (
              <div className="mt-3 flex gap-2">
                <button onClick={() => action(p.id, "verify")} className="rounded-full bg-green-600 px-4 py-2 text-sm text-white">Verify & Approve</button>
                <button onClick={() => action(p.id, "reject")} className="rounded-full bg-red-600 px-4 py-2 text-sm text-white">Reject</button>
              </div>
            )}
          </div>
        ))}
        {payments.length === 0 && <p className="text-gray-500">No payment claims.</p>}
      </div>
    </div>
  );
}
