"use client";

import { useEffect, useState } from "react";

export default function AdminOrdersPage() {
  const [orders, setOrders] = useState<any[]>([]);
  const [selected, setSelected] = useState<any>(null);
  const [items, setItems] = useState<any[]>([]);

  async function load() {
    const res = await fetch("/api/admin/orders");
    const data = await res.json();
    setOrders(data.orders || []);
  }

  useEffect(() => {
    load();
  }, []);

  async function view(order: any) {
    const res = await fetch(`/api/admin/orders/${order.id}`);
    const data = await res.json();
    setSelected(data.order);
    setItems(data.items || []);
  }

  async function updateStatus(id: string, status: string) {
    await fetch(`/api/admin/orders/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status }),
    });
    await load();
    if (selected?.id === id) {
      setSelected((s: any) => ({ ...s, status }));
    }
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Orders</h1>
        <a href="/api/admin/export/orders" className="rounded-full border border-gray-300 px-4 py-2 text-sm">Export CSV</a>
      </div>

      <div className="mt-6 overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b text-left">
              <th className="p-2">Order #</th>
              <th className="p-2">Customer</th>
              <th className="p-2">Phone</th>
              <th className="p-2">Total</th>
              <th className="p-2">Status</th>
              <th className="p-2">Actions</th>
            </tr>
          </thead>
          <tbody>
            {orders.map((o) => (
              <tr key={o.id} className="border-b">
                <td className="p-2">{o.orderNumber}</td>
                <td className="p-2">{o.customerName}</td>
                <td className="p-2">{o.phone}</td>
                <td className="p-2">{o.total}</td>
                <td className="p-2">
                  <select value={o.status} onChange={(e) => updateStatus(o.id, e.target.value)} className="rounded border px-2 py-1">
                    {["pending", "confirmed", "processing", "shipped", "delivered", "cancelled"].map((s) => (
                      <option key={s} value={s}>{s}</option>
                    ))}
                  </select>
                </td>
                <td className="p-2">
                  <button onClick={() => view(o)} className="text-blue-600">View</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {selected && (
        <div className="mt-6 rounded-2xl border border-gray-200 bg-white p-6">
          <h2 className="text-xl font-bold">Order Details</h2>
          <p className="mt-2 text-sm">Customer: {selected.customerName}</p>
          <p className="text-sm">Phone: {selected.phone}</p>
          <p className="text-sm">Email: {selected.email || "-"}</p>
          <p className="text-sm">Address: {selected.address}, {selected.district}</p>
          <p className="text-sm">Subtotal: {selected.subtotal} | Delivery: {selected.deliveryCharge} | Total: {selected.total}</p>
          <ul className="mt-4 space-y-2 text-sm">
            {items.map((i) => (
              <li key={i.id}>{i.productName} × {i.quantity} = {i.lineTotal} BDT</li>
            ))}
          </ul>
          <button onClick={() => setSelected(null)} className="mt-4 text-sm text-gray-500">Close</button>
        </div>
      )}
    </div>
  );
}
