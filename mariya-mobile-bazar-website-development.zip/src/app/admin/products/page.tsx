"use client";

import { useEffect, useState } from "react";

type Product = any;
type Category = any;

const emptyForm = {
  name: "",
  brand: "",
  model: "",
  categoryId: "",
  description: "",
  specifications: "",
  warranty: "",
  condition: "new",
  ram: "",
  storage: "",
  color: "",
  price: 0,
  discountPrice: null as number | null,
  stock: 0,
  sku: "",
  isPublished: false,
  isFeatured: false,
  isBestSeller: false,
  images: [] as string[],
};

export default function AdminProductsPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [form, setForm] = useState<any>(emptyForm);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function load() {
    const [pRes, cRes] = await Promise.all([
      fetch("/api/admin/products"),
      fetch("/api/admin/categories"),
    ]);
    const pData = await pRes.json();
    const cData = await cRes.json();
    setProducts(pData.products || []);
    setCategories(cData.categories || []);
  }

  useEffect(() => {
    load();
  }, []);

  function updateField(key: string, value: any) {
    setForm((f: any) => ({ ...f, [key]: value }));
  }

  async function uploadFile(file: File) {
    const fd = new FormData();
    fd.append("file", file);
    const res = await fetch("/api/admin/upload", { method: "POST", body: fd });
    const data = await res.json();
    if (res.ok) {
      setForm((f: any) => ({ ...f, images: [...f.images, data.url] }));
    } else {
      alert(data.error || "Upload failed");
    }
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    const payload = {
      ...form,
      categoryId: form.categoryId || null,
      discountPrice: form.discountPrice === "" ? null : form.discountPrice,
      images: form.images.map((url: string) => ({ url })),
    };
    const url = editingId ? `/api/admin/products/${editingId}` : "/api/admin/products";
    const method = editingId ? "PUT" : "POST";
    const res = await fetch(url, {
      method,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    const data = await res.json();
    if (!res.ok) {
      alert(data.error || "Failed");
      setLoading(false);
      return;
    }
    setForm(emptyForm);
    setEditingId(null);
    await load();
    setLoading(false);
  }

  function edit(product: any) {
    setEditingId(product.id);
    setForm({
      name: product.name,
      brand: product.brand,
      model: product.model || "",
      categoryId: product.categoryId || "",
      description: product.description || "",
      specifications: product.specifications || "",
      warranty: product.warranty || "",
      condition: product.condition,
      ram: product.ram || "",
      storage: product.storage || "",
      color: product.color || "",
      price: product.price,
      discountPrice: product.discountPrice,
      stock: product.stock,
      sku: product.sku || "",
      isPublished: product.isPublished,
      isFeatured: product.isFeatured,
      isBestSeller: product.isBestSeller,
      images: (product.images || []).map((i: any) => i.url),
    });
  }

  async function remove(id: string) {
    if (!confirm("Delete product?")) return;
    await fetch(`/api/admin/products/${id}`, { method: "DELETE" });
    await load();
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <h1 className="text-2xl font-bold">Products</h1>

      <form onSubmit={submit} className="mt-6 grid gap-3 rounded-2xl border border-gray-200 bg-white p-6 md:grid-cols-3">
        <input required placeholder="Name" value={form.name} onChange={(e) => updateField("name", e.target.value)} className="rounded-lg border border-gray-300 px-3 py-2" />
        <input required placeholder="Brand" value={form.brand} onChange={(e) => updateField("brand", e.target.value)} className="rounded-lg border border-gray-300 px-3 py-2" />
        <input placeholder="Model" value={form.model} onChange={(e) => updateField("model", e.target.value)} className="rounded-lg border border-gray-300 px-3 py-2" />
        <select value={form.categoryId} onChange={(e) => updateField("categoryId", e.target.value)} className="rounded-lg border border-gray-300 px-3 py-2">
          <option value="">No category</option>
          {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>
        <input placeholder="RAM" value={form.ram} onChange={(e) => updateField("ram", e.target.value)} className="rounded-lg border border-gray-300 px-3 py-2" />
        <input placeholder="Storage" value={form.storage} onChange={(e) => updateField("storage", e.target.value)} className="rounded-lg border border-gray-300 px-3 py-2" />
        <input placeholder="Color" value={form.color} onChange={(e) => updateField("color", e.target.value)} className="rounded-lg border border-gray-300 px-3 py-2" />
        <input type="number" placeholder="Price" value={form.price} onChange={(e) => updateField("price", Number(e.target.value))} className="rounded-lg border border-gray-300 px-3 py-2" />
        <input type="number" placeholder="Discount price" value={form.discountPrice ?? ""} onChange={(e) => updateField("discountPrice", e.target.value ? Number(e.target.value) : null)} className="rounded-lg border border-gray-300 px-3 py-2" />
        <input type="number" placeholder="Stock" value={form.stock} onChange={(e) => updateField("stock", Number(e.target.value))} className="rounded-lg border border-gray-300 px-3 py-2" />
        <input placeholder="SKU" value={form.sku} onChange={(e) => updateField("sku", e.target.value)} className="rounded-lg border border-gray-300 px-3 py-2" />
        <select value={form.condition} onChange={(e) => updateField("condition", e.target.value)} className="rounded-lg border border-gray-300 px-3 py-2">
          <option value="new">New</option>
          <option value="used">Used</option>
          <option value="refurbished">Refurbished</option>
        </select>
        <textarea placeholder="Description" value={form.description} onChange={(e) => updateField("description", e.target.value)} className="rounded-lg border border-gray-300 px-3 py-2 md:col-span-3" />
        <textarea placeholder="Specifications" value={form.specifications} onChange={(e) => updateField("specifications", e.target.value)} className="rounded-lg border border-gray-300 px-3 py-2 md:col-span-3" />
        <input placeholder="Warranty" value={form.warranty} onChange={(e) => updateField("warranty", e.target.value)} className="rounded-lg border border-gray-300 px-3 py-2 md:col-span-3" />

        <div className="md:col-span-3 flex flex-wrap gap-4">
          <label className="flex items-center gap-2"><input type="checkbox" checked={form.isPublished} onChange={(e) => updateField("isPublished", e.target.checked)} /> Published</label>
          <label className="flex items-center gap-2"><input type="checkbox" checked={form.isFeatured} onChange={(e) => updateField("isFeatured", e.target.checked)} /> Featured</label>
          <label className="flex items-center gap-2"><input type="checkbox" checked={form.isBestSeller} onChange={(e) => updateField("isBestSeller", e.target.checked)} /> Best seller</label>
        </div>

        <div className="md:col-span-3">
          <label className="block text-sm font-medium">Images</label>
          <input type="file" accept="image/*" onChange={(e) => e.target.files?.[0] && uploadFile(e.target.files[0])} className="mt-1" />
          <div className="mt-2 flex flex-wrap gap-2">
            {form.images.map((url: string, idx: number) => (
              <div key={idx} className="relative">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={url} alt="" className="h-16 w-16 rounded-lg object-cover" />
                <button type="button" onClick={() => updateField("images", form.images.filter((_: string, i: number) => i !== idx))} className="absolute -right-1 -top-1 rounded-full bg-red-600 px-1 text-xs text-white">×</button>
              </div>
            ))}
          </div>
        </div>

        <div className="md:col-span-3 flex gap-3">
          <button disabled={loading} className="rounded-full bg-red-600 px-6 py-2 font-semibold text-white disabled:opacity-50">
            {editingId ? "Update Product" : "Create Product"}
          </button>
          {editingId && (
            <button type="button" onClick={() => { setEditingId(null); setForm(emptyForm); }} className="rounded-full border border-gray-300 px-6 py-2">
              Cancel
            </button>
          )}
        </div>
      </form>

      <div className="mt-8 overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b text-left">
              <th className="p-2">Name</th>
              <th className="p-2">Brand</th>
              <th className="p-2">Price</th>
              <th className="p-2">Stock</th>
              <th className="p-2">Published</th>
              <th className="p-2">Actions</th>
            </tr>
          </thead>
          <tbody>
            {products.map((p) => (
              <tr key={p.id} className="border-b">
                <td className="p-2">{p.name}</td>
                <td className="p-2">{p.brand}</td>
                <td className="p-2">{p.discountPrice ?? p.price}</td>
                <td className="p-2">{p.stock}</td>
                <td className="p-2">{p.isPublished ? "Yes" : "No"}</td>
                <td className="p-2 space-x-2">
                  <button onClick={() => edit(p)} className="text-blue-600">Edit</button>
                  <button onClick={() => remove(p.id)} className="text-red-600">Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
