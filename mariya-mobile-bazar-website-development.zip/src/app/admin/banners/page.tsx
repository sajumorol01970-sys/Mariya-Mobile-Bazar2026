"use client";

import { useEffect, useState } from "react";

export default function AdminBannersPage() {
  const [banners, setBanners] = useState<any[]>([]);
  const [form, setForm] = useState({ title: "", imageUrl: "", subtitle: "", linkUrl: "", isActive: true, sortOrder: 0 });

  async function load() {
    const res = await fetch("/api/admin/banners");
    const data = await res.json();
    setBanners(data.banners || []);
  }

  useEffect(() => { load(); }, []);

  async function add(e: React.FormEvent) {
    e.preventDefault();
    await fetch("/api/admin/banners", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });
    setForm({ title: "", imageUrl: "", subtitle: "", linkUrl: "", isActive: true, sortOrder: 0 });
    await load();
  }

  async function remove(id: string) {
    await fetch(`/api/admin/banners/${id}`, { method: "DELETE" });
    await load();
  }

  return (
    <div className="mx-auto max-w-4xl px-4 py-8">
      <h1 className="text-2xl font-bold">Banners</h1>
      <form onSubmit={add} className="mt-4 space-y-3 rounded-2xl border border-gray-200 bg-white p-6">
        <input required placeholder="Title" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} className="w-full rounded-lg border border-gray-300 px-3 py-2" />
        <input required placeholder="Image URL" value={form.imageUrl} onChange={(e) => setForm({ ...form, imageUrl: e.target.value })} className="w-full rounded-lg border border-gray-300 px-3 py-2" />
        <input placeholder="Subtitle" value={form.subtitle} onChange={(e) => setForm({ ...form, subtitle: e.target.value })} className="w-full rounded-lg border border-gray-300 px-3 py-2" />
        <input placeholder="Link URL" value={form.linkUrl} onChange={(e) => setForm({ ...form, linkUrl: e.target.value })} className="w-full rounded-lg border border-gray-300 px-3 py-2" />
        <button className="rounded-full bg-red-600 px-5 py-2 text-white">Add Banner</button>
      </form>
      <ul className="mt-6 space-y-2">
        {banners.map((b) => (
          <li key={b.id} className="flex items-center justify-between rounded-xl border border-gray-200 bg-white p-3">
            <span>{b.title}</span>
            <button onClick={() => remove(b.id)} className="text-red-600">Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}
