"use client";

import { useEffect, useState } from "react";

export default function AdminReviewsPage() {
  const [reviews, setReviews] = useState<any[]>([]);

  async function load() {
    const res = await fetch("/api/admin/reviews");
    const data = await res.json();
    setReviews(data.reviews || []);
  }

  useEffect(() => { load(); }, []);

  async function toggle(id: string, approved: boolean) {
    await fetch(`/api/admin/reviews/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ isApproved: approved }),
    });
    await load();
  }

  async function remove(id: string) {
    await fetch(`/api/admin/reviews/${id}`, { method: "DELETE" });
    await load();
  }

  return (
    <div className="mx-auto max-w-4xl px-4 py-8">
      <h1 className="text-2xl font-bold">Reviews</h1>
      <div className="mt-6 space-y-3">
        {reviews.map((r) => (
          <div key={r.id} className="rounded-2xl border border-gray-200 bg-white p-4">
            <p className="text-sm">{r.productName} - {r.userName}</p>
            <p className="mt-1">{"★".repeat(r.rating)}</p>
            <p className="mt-1 text-sm text-gray-700">{r.comment}</p>
            <div className="mt-3 flex gap-2">
              <button onClick={() => toggle(r.id, !r.isApproved)} className="text-blue-600 text-sm">
                {r.isApproved ? "Unapprove" : "Approve"}
              </button>
              <button onClick={() => remove(r.id)} className="text-red-600 text-sm">Delete</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
