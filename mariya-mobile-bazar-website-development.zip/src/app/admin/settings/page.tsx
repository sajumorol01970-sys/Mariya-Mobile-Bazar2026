"use client";

import { useEffect, useState } from "react";

export default function AdminSettingsPage() {
  const [form, setForm] = useState<any>({});
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetch("/api/admin/settings").then((r) => r.json()).then(setForm);
  }, []);

  function update(key: string, value: any) {
    setForm((f: any) => ({ ...f, [key]: value }));
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    await fetch("/api/admin/settings", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });
    setLoading(false);
    alert("Saved");
  }

  return (
    <div className="mx-auto max-w-3xl px-4 py-8">
      <h1 className="text-2xl font-bold">Store Settings</h1>
      <form onSubmit={submit} className="mt-6 space-y-4 rounded-2xl border border-gray-200 bg-white p-6">
        <input placeholder="Store name" value={form.storeName || ""} onChange={(e) => update("storeName", e.target.value)} className="w-full rounded-lg border border-gray-300 px-3 py-2" />
        <input placeholder="Phone" value={form.phone || ""} onChange={(e) => update("phone", e.target.value)} className="w-full rounded-lg border border-gray-300 px-3 py-2" />
        <input placeholder="WhatsApp (legacy, unused)" value={form.whatsapp || ""} onChange={(e) => update("whatsapp", e.target.value)} className="w-full rounded-lg border border-gray-300 px-3 py-2" />
        <input placeholder="Email" value={form.email || ""} onChange={(e) => update("email", e.target.value)} className="w-full rounded-lg border border-gray-300 px-3 py-2" />
        <textarea placeholder="Address" value={form.address || ""} onChange={(e) => update("address", e.target.value)} className="w-full rounded-lg border border-gray-300 px-3 py-2" />
        <input type="number" placeholder="Inside delivery charge" value={form.insideDeliveryCharge ?? ""} onChange={(e) => update("insideDeliveryCharge", Number(e.target.value))} className="w-full rounded-lg border border-gray-300 px-3 py-2" />
        <input type="number" placeholder="Outside delivery charge" value={form.outsideDeliveryCharge ?? ""} onChange={(e) => update("outsideDeliveryCharge", Number(e.target.value))} className="w-full rounded-lg border border-gray-300 px-3 py-2" />

        <div className="rounded-xl border border-gray-200 p-4">
          <h2 className="font-semibold">Advance payment</h2>
          <label className="mt-2 flex items-center gap-2">
            <input type="checkbox" checked={!!form.advanceChargeEnabled} onChange={(e) => update("advanceChargeEnabled", e.target.checked)} />
            Enable advance charge
          </label>
          <input type="number" placeholder="Advance amount" value={form.advanceCharge ?? ""} onChange={(e) => update("advanceCharge", Number(e.target.value))} className="mt-2 w-full rounded-lg border border-gray-300 px-3 py-2" />
          <input placeholder="Advance label" value={form.advanceChargeLabel || ""} onChange={(e) => update("advanceChargeLabel", e.target.value)} className="mt-2 w-full rounded-lg border border-gray-300 px-3 py-2" />
        </div>

        <div className="rounded-xl border border-gray-200 p-4">
          <h2 className="font-semibold">bKash</h2>
          <input placeholder="bKash number" value={form.bkashNumber || ""} onChange={(e) => update("bkashNumber", e.target.value)} className="w-full rounded-lg border border-gray-300 px-3 py-2" />
          <select value={form.bkashAccountType || "personal"} onChange={(e) => update("bkashAccountType", e.target.value)} className="mt-2 w-full rounded-lg border border-gray-300 px-3 py-2">
            <option value="personal">Personal</option>
            <option value="merchant">Merchant</option>
          </select>
          <textarea placeholder="bKash instructions" value={form.bkashInstructions || ""} onChange={(e) => update("bkashInstructions", e.target.value)} className="mt-2 w-full rounded-lg border border-gray-300 px-3 py-2" />
        </div>

        <div className="rounded-xl border border-gray-200 p-4">
          <h2 className="font-semibold">Nagad</h2>
          <input placeholder="Nagad number" value={form.nagadNumber || ""} onChange={(e) => update("nagadNumber", e.target.value)} className="w-full rounded-lg border border-gray-300 px-3 py-2" />
          <select value={form.nagadAccountType || "personal"} onChange={(e) => update("nagadAccountType", e.target.value)} className="mt-2 w-full rounded-lg border border-gray-300 px-3 py-2">
            <option value="personal">Personal</option>
            <option value="merchant">Merchant</option>
          </select>
          <textarea placeholder="Nagad instructions" value={form.nagadInstructions || ""} onChange={(e) => update("nagadInstructions", e.target.value)} className="mt-2 w-full rounded-lg border border-gray-300 px-3 py-2" />
        </div>

        <button disabled={loading} className="rounded-full bg-red-600 px-6 py-3 font-semibold text-white disabled:opacity-50">
          {loading ? "Saving..." : "Save Settings"}
        </button>
      </form>
    </div>
  );
}
