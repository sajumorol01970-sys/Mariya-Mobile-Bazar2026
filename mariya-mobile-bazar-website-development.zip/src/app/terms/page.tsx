export default function TermsPage() {
  return (
    <div className="mx-auto max-w-3xl px-4 py-8 prose">
      <h1>Terms and Conditions</h1>
      <p>Orders are subject to stock availability and payment verification.</p>
    </div>
  );
}