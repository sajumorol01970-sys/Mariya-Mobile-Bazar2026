"use client";

import { useState } from "react";

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const [resetUrl, setResetUrl] = useState("");

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    const res = await fetch("/api/auth/forgot-password", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email }),
    });
    const data = await res.json();
    setMessage(data.message || "Done");
    if (data.resetUrl) setResetUrl(data.resetUrl);
  }

  return (
    <div className="mx-auto max-w-md px-4 py-12">
      <h1 className="text-2xl font-bold">Forgot Password</h1>
      <form onSubmit={submit} className="mt-6 space-y-4 rounded-2xl border border-gray-200 bg-white p-6">
        <input type="email" required placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} className="w-full rounded-lg border border-gray-300 px-3 py-2" />
        <button className="w-full rounded-full bg-red-600 py-3 font-semibold text-white">Send Reset Link</button>
      </form>
      {message && <p className="mt-4 text-sm text-gray-600">{message}</p>}
      {resetUrl && (
        <p className="mt-2 break-all text-xs text-gray-500">
          Dev reset link: <a href={resetUrl} className="text-red-600">{resetUrl}</a>
        </p>
      )}
    </div>
  );
}
