import { NextResponse } from "next/server";
import { db } from "@/db";
import { products, productImages, categories } from "@/db/schema";
import { eq, and, ne } from "drizzle-orm";

export async function GET(_request: Request, { params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const [product] = await db.select().from(products).where(eq(products.slug, slug)).limit(1);
  if (!product || !product.isPublished) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const images = await db
    .select()
    .from(productImages)
    .where(eq(productImages.productId, product.id))
    .orderBy(productImages.sortOrder);

  let category = null;
  if (product.categoryId) {
    const [c] = await db.select().from(categories).where(eq(categories.id, product.categoryId)).limit(1);
    category = c || null;
  }

  const relatedQuery = product.categoryId
    ? db
        .select({
          id: products.id,
          name: products.name,
          slug: products.slug,
          brand: products.brand,
          price: products.price,
          discountPrice: products.discountPrice,
          stock: products.stock,
        })
        .from(products)
        .where(and(eq(products.isPublished, true), ne(products.id, product.id), eq(products.categoryId, product.categoryId)))
        .limit(4)
    : db
        .select({
          id: products.id,
          name: products.name,
          slug: products.slug,
          brand: products.brand,
          price: products.price,
          discountPrice: products.discountPrice,
          stock: products.stock,
        })
        .from(products)
        .where(and(eq(products.isPublished, true), ne(products.id, product.id)))
        .limit(4);
  const related = await relatedQuery;

  return NextResponse.json({ product, images, category, related });
}
