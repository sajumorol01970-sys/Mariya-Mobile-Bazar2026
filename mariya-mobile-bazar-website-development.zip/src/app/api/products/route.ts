import { NextResponse } from "next/server";
import { db } from "@/db";
import { products, productImages, categories } from "@/db/schema";
import { and, asc, desc, eq, ilike, or, sql, inArray } from "drizzle-orm";

export async function GET(request: Request) {
  const url = new URL(request.url);
  const q = url.searchParams.get("q")?.trim();
  const categorySlug = url.searchParams.get("category");
  const brand = url.searchParams.get("brand");
  const sort = url.searchParams.get("sort") || "newest";
  const page = Math.max(1, Number(url.searchParams.get("page") || 1));
  const limit = Math.min(48, Math.max(1, Number(url.searchParams.get("limit") || 24)));
  const offset = (page - 1) * limit;

  const conditions = [eq(products.isPublished, true)];
  if (q) {
    conditions.push(
      or(
        ilike(products.name, `%${q}%`),
        ilike(products.brand, `%${q}%`),
        ilike(products.model, `%${q}%`),
      )!,
    );
  }
  if (brand) conditions.push(eq(products.brand, brand));
  if (categorySlug) {
    const [cat] = await db.select().from(categories).where(eq(categories.slug, categorySlug)).limit(1);
    if (cat) conditions.push(eq(products.categoryId, cat.id));
  }

  const orderBy =
    sort === "price_asc"
      ? asc(products.discountPrice)
      : sort === "price_desc"
        ? desc(products.discountPrice)
        : sort === "popular"
          ? desc(products.isBestSeller)
          : desc(products.createdAt);

  const rows = await db
    .select({
      id: products.id,
      name: products.name,
      slug: products.slug,
      brand: products.brand,
      price: products.price,
      discountPrice: products.discountPrice,
      stock: products.stock,
      isFeatured: products.isFeatured,
      isBestSeller: products.isBestSeller,
      createdAt: products.createdAt,
    })
    .from(products)
    .where(and(...conditions))
    .orderBy(orderBy)
    .limit(limit)
    .offset(offset);

  const ids = rows.map((r) => r.id);
  const images = ids.length
    ? await db
        .select()
        .from(productImages)
        .where(inArray(productImages.productId, ids))
    : [];
  const firstImageByProduct = new Map<string, string>();
  for (const img of images) {
    if (!firstImageByProduct.has(img.productId)) firstImageByProduct.set(img.productId, img.url);
  }

  const result = rows.map((r) => ({
    ...r,
    imageUrl: firstImageByProduct.get(r.id) || null,
  }));

  return NextResponse.json({ products: result, page, limit });
}
