import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/db";
import { products, orders, orderItems, storeSettings } from "@/db/schema";
import { eq, sql, inArray } from "drizzle-orm";
import { getSession } from "@/lib/auth";

const itemSchema = z.object({
  productId: z.string().uuid(),
  quantity: z.number().int().min(1).max(20),
});

const schema = z.object({
  customerName: z.string().min(2),
  phone: z.string().min(8),
  email: z.string().email().optional().or(z.literal("")),
  address: z.string().min(5),
  district: z.string().min(2),
  notes: z.string().optional(),
  items: z.array(itemSchema).min(1),
});

export async function POST(request: Request) {
  const session = await getSession();
  try {
    const data = schema.parse(await request.json());

    const result = await db.transaction(async (tx) => {
      const [settings] = await tx.select().from(storeSettings).limit(1);
      const insideCharge = settings?.insideDeliveryCharge ?? 80;
      const outsideCharge = settings?.outsideDeliveryCharge ?? 150;
      const isDhaka = data.district.toLowerCase().includes("dhaka") || data.district.toLowerCase().includes("ঢাকা");
      const deliveryCharge = isDhaka ? insideCharge : outsideCharge;

      const advanceCharge = settings?.advanceChargeEnabled ? settings.advanceCharge ?? 0 : 0;

      const productIds = data.items.map((i) => i.productId);
      const dbProducts = await tx.select().from(products).where(inArray(products.id, productIds));
      const byId = new Map(dbProducts.map((p) => [p.id, p]));

      let subtotal = 0;
      const prepared: Array<{ product: typeof dbProducts[number]; quantity: number; unitPrice: number }> = [];
      for (const item of data.items) {
        const product = byId.get(item.productId);
        if (!product || !product.isPublished) throw new Error("Product unavailable");
        if (product.stock < item.quantity) throw new Error(`Insufficient stock for ${product.name}`);
        const unitPrice = product.discountPrice ?? product.price;
        subtotal += unitPrice * item.quantity;
        prepared.push({ product, quantity: item.quantity, unitPrice });
      }

      const total = subtotal + deliveryCharge;
      if (advanceCharge > total) throw new Error("Advance amount cannot exceed order total");
      const remainingAmount = total - advanceCharge;

      const orderNumber = `MMB-${Date.now()}-${Math.floor(Math.random() * 1000)
        .toString()
        .padStart(3, "0")}`;

      const [order] = await tx
        .insert(orders)
        .values({
          orderNumber,
          userId: session?.id ?? null,
          customerName: data.customerName,
          phone: data.phone,
          email: data.email || null,
          address: data.address,
          district: data.district,
          subtotal,
          deliveryCharge,
          total,
          advanceAmount: advanceCharge,
          remainingAmount,
          notes: data.notes,
          status: "awaiting_approval",
          paymentStatus: "pending_verification",
        })
        .returning();

      for (const p of prepared) {
        await tx.insert(orderItems).values({
          orderId: order.id,
          productId: p.product.id,
          productName: p.product.name,
          unitPrice: p.unitPrice,
          quantity: p.quantity,
          lineTotal: p.unitPrice * p.quantity,
        });
        await tx
          .update(products)
          .set({ stock: p.product.stock - p.quantity, updatedAt: new Date() })
          .where(eq(products.id, p.product.id));
      }

      return { order, orderNumber };
    });

    return NextResponse.json({ orderNumber: result.orderNumber, orderId: result.order.id });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ error: error.issues }, { status: 400 });
    }
    console.error(error);
    return NextResponse.json({ error: error instanceof Error ? error.message : "Checkout failed" }, { status: 400 });
  }
}
