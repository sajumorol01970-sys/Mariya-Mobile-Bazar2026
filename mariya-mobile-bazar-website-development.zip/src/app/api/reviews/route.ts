import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/db";
import { reviews, products } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { getSession } from "@/lib/auth";

export async function GET(request: Request) {
  const url = new URL(request.url);
  const productId = url.searchParams.get("productId");
  if (!productId) return NextResponse.json({ reviews: [] });
  const rows = await db
    .select()
    .from(reviews)
    .where(eq(reviews.productId, productId))
    .orderBy(desc(reviews.createdAt));
  return NextResponse.json({ reviews: rows });
}

const schema = z.object({
  productId: z.string().uuid(),
  rating: z.number().int().min(1).max(5),
  comment: z.string().min(3),
});

export async function POST(request: Request) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  try {
    const data = schema.parse(await request.json());
    const [product] = await db.select().from(products).where(eq(products.id, data.productId)).limit(1);
    if (!product) return NextResponse.json({ error: "Product not found" }, { status: 404 });
    const [review] = await db
      .insert(reviews)
      .values({
        productId: data.productId,
        userId: session.id,
        rating: data.rating,
        comment: data.comment,
        isApproved: false,
      })
      .returning();
    return NextResponse.json({ review });
  } catch (error) {
    if (error instanceof z.ZodError) return NextResponse.json({ error: error.issues }, { status: 400 });
    console.error(error);
    return NextResponse.json({ error: "Failed" }, { status: 500 });
  }
}
