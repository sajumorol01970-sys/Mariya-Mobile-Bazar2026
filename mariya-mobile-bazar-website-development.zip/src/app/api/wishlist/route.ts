import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/db";
import { wishlists, products, productImages } from "@/db/schema";
import { eq, and, sql, inArray } from "drizzle-orm";
import { getSession } from "@/lib/auth";

export async function GET() {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const rows = await db
    .select({ productId: wishlists.productId })
    .from(wishlists)
    .where(eq(wishlists.userId, session.id));

  const ids = rows.map((r) => r.productId);
  if (!ids.length) return NextResponse.json({ products: [] });

  const prods = await db.select().from(products).where(inArray(products.id, ids));
  const images = await db.select().from(productImages).where(inArray(productImages.productId, ids));
  const first = new Map<string, string>();
  for (const img of images) if (!first.has(img.productId)) first.set(img.productId, img.url);

  return NextResponse.json({
    products: prods.map((p) => ({ ...p, imageUrl: first.get(p.id) || null })),
  });
}

const schema = z.object({ productId: z.string().uuid() });

export async function POST(request: Request) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  try {
    const { productId } = schema.parse(await request.json());
    const existing = await db
      .select()
      .from(wishlists)
      .where(and(eq(wishlists.userId, session.id), eq(wishlists.productId, productId)))
      .limit(1);
    if (existing.length) {
      await db.delete(wishlists).where(and(eq(wishlists.userId, session.id), eq(wishlists.productId, productId)));
      return NextResponse.json({ wishlisted: false });
    }
    await db.insert(wishlists).values({ userId: session.id, productId });
    return NextResponse.json({ wishlisted: true });
  } catch (error) {
    if (error instanceof z.ZodError) return NextResponse.json({ error: error.issues }, { status: 400 });
    console.error(error);
    return NextResponse.json({ error: "Failed" }, { status: 500 });
  }
}
