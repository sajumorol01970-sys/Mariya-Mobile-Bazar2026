import { NextResponse } from "next/server";
import { db } from "@/db";
import { storeSettings } from "@/db/schema";

export async function GET() {
  let [settings] = await db.select().from(storeSettings).limit(1);
  if (!settings) {
    [settings] = await db.insert(storeSettings).values({}).returning();
  }
  return NextResponse.json(settings);
}
