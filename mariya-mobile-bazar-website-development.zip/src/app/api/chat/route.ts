import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/db";
import { products, storeSettings, orders } from "@/db/schema";
import { getSession } from "@/lib/auth";
import { ilike, or, eq, desc } from "drizzle-orm";
import OpenAI from "openai";

const schema = z.object({
  message: z.string().min(1).max(1000),
  history: z
    .array(z.object({ role: z.enum(["user", "assistant"]), content: z.string() }))
    .default([]),
});

function extractKeywords(message: string) {
  return message
    .toLowerCase()
    .split(/[\s,?.!]+/)
    .filter((w) => w.length > 2)
    .slice(0, 8);
}

export async function POST(request: Request) {
  try {
    const { message, history } = schema.parse(await request.json());

    const keywords = extractKeywords(message);
    const matched = keywords.length
      ? await db
          .select()
          .from(products)
          .where(
            or(
              ...keywords.map((k) => ilike(products.name, `%${k}%`)),
              ...keywords.map((k) => ilike(products.brand, `%${k}%`)),
            ),
          )
          .orderBy(desc(products.createdAt))
          .limit(8)
      : await db.select().from(products).where(eq(products.isPublished, true)).orderBy(desc(products.createdAt)).limit(8);

    const session = await getSession();
    let orderContext = "";
    if (session) {
      const userOrders = await db.select().from(orders).where(eq(orders.userId, session.id)).orderBy(desc(orders.createdAt)).limit(5);
      orderContext = userOrders.map((o) => `Order ${o.orderNumber}: status ${o.status}, payment ${o.paymentStatus}, total ${o.total} BDT, remaining ${o.remainingAmount} BDT`).join("\n");
    }

    const [settings] = await db.select().from(storeSettings).limit(1);

    const productContext = matched
      .map((p) => {
        const price = p.discountPrice ?? p.price;
        return `- ${p.name} (${p.brand}) | Price: ${price} BDT${p.discountPrice ? ` (was ${p.price})` : ""} | Stock: ${p.stock} | RAM: ${p.ram || "N/A"} | Storage: ${p.storage || "N/A"} | Color: ${p.color || "N/A"} | Condition: ${p.condition} | Warranty: ${p.warranty || "N/A"}`;
      })
      .join("\n");

    const system = `You are a helpful customer support assistant for Mariya Mobile Bazar, a mobile phone shop in Benapole, Jessore, Bangladesh.
Answer in the same language as the user (Bengali or English).
Use only the provided product data and store policies. Never invent prices, stock, warranties, or order status.
If information is unavailable, say so and direct to WhatsApp.
Store: ${settings?.storeName || "Mariya Mobile Bazar"}, phone ${settings?.phone || ""}, address ${settings?.address || ""}.
Delivery charge inside Dhaka: ${settings?.insideDeliveryCharge ?? 80} BDT, outside: ${settings?.outsideDeliveryCharge ?? 150} BDT. Cash on delivery available.
Products:
${productContext || "No matching products found in database."}
${orderContext ? `Customer orders:\n${orderContext}` : ""}
If the user asks about order tracking, ask for order number and phone and direct to /track. Do not claim to know an order status without verification.`;

    if (process.env.OPENAI_API_KEY) {
      const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
      const completion = await client.chat.completions.create({
        model: process.env.OPENAI_MODEL || "gpt-4o-mini",
        messages: [
          { role: "system", content: system },
          ...history.slice(-8).map((m) => ({ role: m.role, content: m.content })),
          { role: "user", content: message },
        ],
        temperature: 0.3,
      });
      const reply = completion.choices[0]?.message?.content || "দুঃখিত, উত্তর পাওয়া যায়নি।";
      return NextResponse.json({ reply });
    }

    let reply = "";
    if (matched.length) {
      reply =
        `আমি ডাটাবেস থেকে ${matched.length}টি পণ্য পেয়েছি:\n` +
        matched.map((p) => `${p.name} - ${p.discountPrice ?? p.price} BDT (Stock: ${p.stock})`).join("\n");
      reply += "\n\nআরও বিস্তারিত জানতে পণ্যের পেজ দেখুন বা WhatsApp-এ যোগায়োগ করুন।";
    } else {
      reply = "দুঃখিত, আপনার প্রশ্নের সাথে মিলে এমন কোনো পণ্য ডাটাবেসে পাওয়া যায়নি। WhatsApp-এ যোগায়োগ করুন।";
    }
    if (message.toLowerCase().includes("delivery") || message.includes("ডেলিভারি")) {
      reply += `\n\nডেলিভারি চার্জ: ঢাকার ভিতরে ${settings?.insideDeliveryCharge ?? 80} BDT, বাইরে ${settings?.outsideDeliveryCharge ?? 150} BDT।`;
    }
    return NextResponse.json({ reply });
  } catch (error) {
    if (error instanceof z.ZodError) return NextResponse.json({ error: error.issues }, { status: 400 });
    console.error(error);
    return NextResponse.json({ reply: "দুঃখিত, সমস্যা হয়েছে। WhatsApp-এ যোগায়োগ করুন।" }, { status: 500 });
  }
}
