import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/db";
import { payments, orders, orderItems, products } from "@/db/schema";
import { eq, sql } from "drizzle-orm";
import { getSession } from "@/lib/auth";

async function requireAdmin() {
  const session = await getSession();
  if (!session || session.role !== "admin") return null;
  return session;
}

const schema = z.object({
  action: z.enum(["verify", "reject"]),
  reason: z.string().optional(),
});

export async function PUT(request: Request, { params }: { params: Promise<{ id: string }> }) {
  if (!(await requireAdmin())) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const { id } = await params;
  const session = await getSession();
  try {
    const { action, reason } = schema.parse(await request.json());

    await db.transaction(async (tx) => {
      const [payment] = await tx.select().from(payments).where(eq(payments.id, id)).limit(1);
      if (!payment) throw new Error("Payment not found");
      if (payment.status !== "pending_verification") throw new Error("Payment already processed");

      const now = new Date();
      if (action === "verify") {
        await tx
          .update(payments)
          .set({ status: "verified", verifiedAt: now, verifiedBy: session!.id })
          .where(eq(payments.id, id));
        await tx
          .update(orders)
          .set({ paymentStatus: "verified", status: "confirmed", paymentVerifiedAt: now, paymentVerifiedBy: session!.id, updatedAt: now })
          .where(eq(orders.id, payment.orderId));
      } else {
        await tx
          .update(payments)
          .set({ status: "rejected", verifiedAt: now, verifiedBy: session!.id, rejectionReason: reason })
          .where(eq(payments.id, id));
        // restore stock
        const items = await tx.select().from(orderItems).where(eq(orderItems.orderId, payment.orderId));
        for (const item of items) {
          if (item.productId) {
            await tx
              .update(products)
              .set({ stock: sql`stock + ${item.quantity}`, updatedAt: now })
              .where(eq(products.id, item.productId));
          }
        }
        await tx
          .update(orders)
          .set({ paymentStatus: "rejected", status: "rejected", rejectionReason: reason, updatedAt: now })
          .where(eq(orders.id, payment.orderId));
      }
    });

    return NextResponse.json({ ok: true });
  } catch (error) {
    if (error instanceof z.ZodError) return NextResponse.json({ error: error.issues }, { status: 400 });
    console.error(error);
    return NextResponse.json({ error: error instanceof Error ? error.message : "Update failed" }, { status: 400 });
  }
}
