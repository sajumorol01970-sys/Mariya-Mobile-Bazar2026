import { NextResponse } from "next/server";
import { db } from "@/db";
import { payments, orders } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { getSession } from "@/lib/auth";

async function requireAdmin() {
  const session = await getSession();
  if (!session || session.role !== "admin") return null;
  return session;
}

export async function GET() {
  if (!(await requireAdmin())) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const rows = await db.select().from(payments).orderBy(desc(payments.submittedAt));
  const orderIds = [...new Set(rows.map((r) => r.orderId))];
  const ords = orderIds.length ? await db.select().from(orders) : [];
  const omap = new Map(ords.map((o) => [o.id, o]));
  return NextResponse.json({
    payments: rows.map((p) => ({ ...p, order: omap.get(p.orderId) || null })),
  });
}
