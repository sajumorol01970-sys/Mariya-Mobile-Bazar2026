import { NextResponse } from "next/server";
import { db } from "@/db";
import { orders, products, users } from "@/db/schema";
import { count, sum, sql } from "drizzle-orm";
import { getSession } from "@/lib/auth";

async function requireAdmin() {
  const session = await getSession();
  if (!session || session.role !== "admin") return null;
  return session;
}

export async function GET() {
  if (!(await requireAdmin())) return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  const [orderCount] = await db.select({ value: count() }).from(orders);
  const [sales] = await db.select({ value: sum(orders.total) }).from(orders);
  const [productCount] = await db.select({ value: count() }).from(products);
  const [customerCount] = await db.select({ value: count() }).from(users).where(sql`${users.role} = 'customer'`);
  const [lowStock] = await db.select({ value: count() }).from(products).where(sql`${products.stock} <= 5`);
  const recentOrders = await db.select().from(orders).orderBy(sql`${orders.createdAt} desc`).limit(5);

  return NextResponse.json({
    totalOrders: Number(orderCount.value || 0),
    totalSales: Number(sales.value || 0),
    totalProducts: Number(productCount.value || 0),
    totalCustomers: Number(customerCount.value || 0),
    lowStock: Number(lowStock.value || 0),
    recentOrders,
  });
}
