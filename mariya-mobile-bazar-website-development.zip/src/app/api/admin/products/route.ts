import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/db";
import { products, productImages, categories } from "@/db/schema";
import { eq, desc, sql, inArray } from "drizzle-orm";
import { getSession } from "@/lib/auth";

async function requireAdmin() {
  const session = await getSession();
  if (!session || session.role !== "admin") return null;
  return session;
}

const imageSchema = z.object({
  url: z.string().min(1),
  alt: z.string().optional(),
});

const schema = z.object({
  name: z.string().min(2),
  brand: z.string().min(1),
  model: z.string().optional(),
  categoryId: z.string().uuid().optional().or(z.literal("")),
  description: z.string().optional(),
  specifications: z.string().optional(),
  warranty: z.string().optional(),
  condition: z.enum(["new", "used", "refurbished"]).default("new"),
  ram: z.string().optional(),
  storage: z.string().optional(),
  color: z.string().optional(),
  price: z.number().int().min(0),
  discountPrice: z.number().int().min(0).optional().nullable(),
  stock: z.number().int().min(0),
  sku: z.string().optional(),
  isPublished: z.boolean().default(false),
  isFeatured: z.boolean().default(false),
  isBestSeller: z.boolean().default(false),
  images: z.array(imageSchema).default([]),
});

export async function GET() {
  if (!(await requireAdmin())) return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  const rows = await db.select().from(products).orderBy(desc(products.createdAt));
  const ids = rows.map((r) => r.id);
  const images = ids.length
    ? await db.select().from(productImages).where(sql`${productImages.productId} = ANY(${ids})`)
    : [];
  const byProduct = new Map<string, typeof images>();
  for (const img of images) {
    if (!byProduct.has(img.productId)) byProduct.set(img.productId, []);
    byProduct.get(img.productId)!.push(img);
  }
  const cats = await db.select().from(categories);
  const catMap = new Map(cats.map((c) => [c.id, c]));

  return NextResponse.json({
    products: rows.map((p) => ({
      ...p,
      images: byProduct.get(p.id) || [],
      category: p.categoryId ? catMap.get(p.categoryId) || null : null,
    })),
  });
}

export async function POST(request: Request) {
  if (!(await requireAdmin())) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  try {
    const data = schema.parse(await request.json());
    const slugBase = data.name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
    const slug = `${slugBase}-${Date.now().toString(36)}`;

    const [product] = await db
      .insert(products)
      .values({
        name: data.name,
        slug,
        brand: data.brand,
        model: data.model || null,
        categoryId: data.categoryId || null,
        description: data.description || null,
        specifications: data.specifications || null,
        warranty: data.warranty || null,
        condition: data.condition,
        ram: data.ram || null,
        storage: data.storage || null,
        color: data.color || null,
        price: data.price,
        discountPrice: data.discountPrice ?? null,
        stock: data.stock,
        sku: data.sku || null,
        isPublished: data.isPublished,
        isFeatured: data.isFeatured,
        isBestSeller: data.isBestSeller,
      })
      .returning();

    if (data.images.length) {
      await db.insert(productImages).values(
        data.images.map((img, idx) => ({
          productId: product.id,
          url: img.url,
          alt: img.alt || product.name,
          sortOrder: idx,
        })),
      );
    }

    return NextResponse.json({ product });
  } catch (error) {
    if (error instanceof z.ZodError) return NextResponse.json({ error: error.issues }, { status: 400 });
    console.error(error);
    return NextResponse.json({ error: "Create failed" }, { status: 500 });
  }
}
