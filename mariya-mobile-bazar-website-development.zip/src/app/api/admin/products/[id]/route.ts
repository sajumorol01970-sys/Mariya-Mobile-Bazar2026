import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/db";
import { products, productImages } from "@/db/schema";
import { eq, sql } from "drizzle-orm";
import { getSession } from "@/lib/auth";

async function requireAdmin() {
  const session = await getSession();
  if (!session || session.role !== "admin") return null;
  return session;
}

const imageSchema = z.object({ url: z.string().min(1), alt: z.string().optional() });

const schema = z.object({
  name: z.string().min(2).optional(),
  brand: z.string().min(1).optional(),
  model: z.string().optional().nullable(),
  categoryId: z.string().uuid().optional().nullable().or(z.literal("")),
  description: z.string().optional().nullable(),
  specifications: z.string().optional().nullable(),
  warranty: z.string().optional().nullable(),
  condition: z.enum(["new", "used", "refurbished"]).optional(),
  ram: z.string().optional().nullable(),
  storage: z.string().optional().nullable(),
  color: z.string().optional().nullable(),
  price: z.number().int().min(0).optional(),
  discountPrice: z.number().int().min(0).optional().nullable(),
  stock: z.number().int().min(0).optional(),
  sku: z.string().optional().nullable(),
  isPublished: z.boolean().optional(),
  isFeatured: z.boolean().optional(),
  isBestSeller: z.boolean().optional(),
  images: z.array(imageSchema).optional(),
});

export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  if (!(await requireAdmin())) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const { id } = await params;
  const [product] = await db.select().from(products).where(eq(products.id, id)).limit(1);
  if (!product) return NextResponse.json({ error: "Not found" }, { status: 404 });
  const images = await db.select().from(productImages).where(eq(productImages.productId, id)).orderBy(productImages.sortOrder);
  return NextResponse.json({ product, images });
}

export async function PUT(request: Request, { params }: { params: Promise<{ id: string }> }) {
  if (!(await requireAdmin())) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const { id } = await params;
  try {
    const data = schema.parse(await request.json());
    const update: Record<string, unknown> = { updatedAt: new Date() };
    for (const [key, value] of Object.entries(data)) {
      if (key === "images") continue;
      if (value === "") update[key === "categoryId" ? "categoryId" : key] = null;
      else if (value !== undefined) update[key] = value;
    }
    if ("categoryId" in data) update.categoryId = data.categoryId || null;

    const [product] = await db.update(products).set(update).where(eq(products.id, id)).returning();
    if (!product) return NextResponse.json({ error: "Not found" }, { status: 404 });

    if (data.images) {
      await db.delete(productImages).where(eq(productImages.productId, id));
      if (data.images.length) {
        await db.insert(productImages).values(
          data.images.map((img, idx) => ({
            productId: id,
            url: img.url,
            alt: img.alt || product.name,
            sortOrder: idx,
          })),
        );
      }
    }

    return NextResponse.json({ product });
  } catch (error) {
    if (error instanceof z.ZodError) return NextResponse.json({ error: error.issues }, { status: 400 });
    console.error(error);
    return NextResponse.json({ error: "Update failed" }, { status: 500 });
  }
}

export async function DELETE(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  if (!(await requireAdmin())) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const { id } = await params;
  await db.delete(products).where(eq(products.id, id));
  return NextResponse.json({ ok: true });
}
