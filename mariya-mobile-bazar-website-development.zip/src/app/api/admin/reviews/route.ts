import { NextResponse } from "next/server";
import { db } from "@/db";
import { reviews, products, users } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { getSession } from "@/lib/auth";

async function requireAdmin() {
  const session = await getSession();
  if (!session || session.role !== "admin") return null;
  return session;
}

export async function GET() {
  if (!(await requireAdmin())) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const rows = await db.select().from(reviews).orderBy(desc(reviews.createdAt));
  const productIds = [...new Set(rows.map((r) => r.productId))];
  const userIds = [...new Set(rows.map((r) => r.userId))];
  const prods = productIds.length ? await db.select().from(products) : [];
  const usrs = userIds.length ? await db.select().from(users) : [];
  const pmap = new Map(prods.map((p) => [p.id, p.name]));
  const umap = new Map(usrs.map((u) => [u.id, u.name]));
  return NextResponse.json({
    reviews: rows.map((r) => ({
      ...r,
      productName: pmap.get(r.productId) || "",
      userName: umap.get(r.userId) || "",
    })),
  });
}
