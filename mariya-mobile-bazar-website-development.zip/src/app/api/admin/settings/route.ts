import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/db";
import { storeSettings } from "@/db/schema";
import { eq } from "drizzle-orm";
import { getSession } from "@/lib/auth";

async function requireAdmin() {
  const session = await getSession();
  if (!session || session.role !== "admin") return null;
  return session;
}

const schema = z.object({
  storeName: z.string().min(1).optional(),
  phone: z.string().min(1).optional(),
  whatsapp: z.string().min(1).optional(),
  email: z.string().email().optional(),
  address: z.string().min(1).optional(),
  insideDeliveryCharge: z.number().int().min(0).optional(),
  outsideDeliveryCharge: z.number().int().min(0).optional(),
  freeDeliveryThreshold: z.number().int().min(0).optional().nullable(),
  advanceCharge: z.number().int().min(0).optional(),
  advanceChargeEnabled: z.boolean().optional(),
  advanceChargeLabel: z.string().optional(),
  bkashNumber: z.string().optional().nullable(),
  bkashAccountType: z.string().optional().nullable(),
  bkashInstructions: z.string().optional().nullable(),
  nagadNumber: z.string().optional().nullable(),
  nagadAccountType: z.string().optional().nullable(),
  nagadInstructions: z.string().optional().nullable(),
  paymentMethodsEnabled: z.boolean().optional(),
});

export async function GET() {
  if (!(await requireAdmin())) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  let [settings] = await db.select().from(storeSettings).limit(1);
  if (!settings) [settings] = await db.insert(storeSettings).values({}).returning();
  return NextResponse.json(settings);
}

export async function PUT(request: Request) {
  if (!(await requireAdmin())) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  try {
    const data = schema.parse(await request.json());
    let [settings] = await db.select().from(storeSettings).limit(1);
    if (!settings) [settings] = await db.insert(storeSettings).values({}).returning();
    const [updated] = await db
      .update(storeSettings)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(storeSettings.id, settings.id))
      .returning();
    return NextResponse.json(updated);
  } catch (error) {
    if (error instanceof z.ZodError) return NextResponse.json({ error: error.issues }, { status: 400 });
    console.error(error);
    return NextResponse.json({ error: "Update failed" }, { status: 500 });
  }
}


