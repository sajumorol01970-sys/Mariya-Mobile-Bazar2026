import { NextResponse } from "next/server";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { desc } from "drizzle-orm";
import { getSession } from "@/lib/auth";

async function requireAdmin() {
  const session = await getSession();
  if (!session || session.role !== "admin") return null;
  return session;
}

export async function GET() {
  if (!(await requireAdmin())) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const rows = await db.select().from(orders).orderBy(desc(orders.createdAt));
  const header = ["orderNumber", "customerName", "phone", "district", "subtotal", "deliveryCharge", "total", "status", "createdAt"];
  const lines = [header.join(",")];
  for (const o of rows) {
    lines.push(
      [
        o.orderNumber,
        `"${o.customerName.replace(/"/g, '""')}"`,
        o.phone,
        o.district,
        o.subtotal,
        o.deliveryCharge,
        o.total,
        o.status,
        o.createdAt.toISOString(),
      ].join(","),
    );
  }
  return new NextResponse(lines.join("\n"), {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": 'attachment; filename="orders.csv"',
    },
  });
}
