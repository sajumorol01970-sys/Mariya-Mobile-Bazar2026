import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/db";
import { orders, orderItems, products } from "@/db/schema";
import { eq, sql } from "drizzle-orm";
import { getSession } from "@/lib/auth";

async function requireAdmin() {
  const session = await getSession();
  if (!session || session.role !== "admin") return null;
  return session;
}

const schema = z.object({
  status: z.enum(["pending", "confirmed", "processing", "shipped", "delivered", "cancelled"]),
});

export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  if (!(await requireAdmin())) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const { id } = await params;
  const [order] = await db.select().from(orders).where(eq(orders.id, id)).limit(1);
  if (!order) return NextResponse.json({ error: "Not found" }, { status: 404 });
  const items = await db.select().from(orderItems).where(eq(orderItems.orderId, id));
  return NextResponse.json({ order, items });
}

export async function PUT(request: Request, { params }: { params: Promise<{ id: string }> }) {
  if (!(await requireAdmin())) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const { id } = await params;
  try {
    const { status } = schema.parse(await request.json());

    await db.transaction(async (tx) => {
      const [order] = await tx.select().from(orders).where(eq(orders.id, id)).limit(1);
      if (!order) throw new Error("Order not found");
      if (order.status === status) return;

      // Restore stock if cancelling an uncancelled order.
      if (status === "cancelled" && order.status !== "cancelled") {
        const items = await tx.select().from(orderItems).where(eq(orderItems.orderId, id));
        for (const item of items) {
          if (item.productId) {
            await tx
              .update(products)
              .set({ stock: sql`stock + ${item.quantity}`, updatedAt: new Date() })
              .where(eq(products.id, item.productId));
          }
        }
      }

      // If re-opening a cancelled order, decrement stock again.
      if (order.status === "cancelled" && status !== "cancelled") {
        const items = await tx.select().from(orderItems).where(eq(orderItems.orderId, id));
        for (const item of items) {
          if (item.productId) {
            const [product] = await tx.select().from(products).where(eq(products.id, item.productId)).limit(1);
            if (!product || product.stock < item.quantity) throw new Error("Insufficient stock");
            await tx
              .update(products)
              .set({ stock: product.stock - item.quantity, updatedAt: new Date() })
              .where(eq(products.id, item.productId));
          }
        }
      }

      await tx.update(orders).set({ status, updatedAt: new Date() }).where(eq(orders.id, id));
    });

    return NextResponse.json({ ok: true });
  } catch (error) {
    if (error instanceof z.ZodError) return NextResponse.json({ error: error.issues }, { status: 400 });
    console.error(error);
    return NextResponse.json({ error: error instanceof Error ? error.message : "Update failed" }, { status: 400 });
  }
}
