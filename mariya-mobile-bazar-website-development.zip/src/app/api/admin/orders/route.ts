import { NextResponse } from "next/server";
import { db } from "@/db";
import { orders, orderItems } from "@/db/schema";
import { desc, eq, sql } from "drizzle-orm";
import { getSession } from "@/lib/auth";

async function requireAdmin() {
  const session = await getSession();
  if (!session || session.role !== "admin") return null;
  return session;
}

export async function GET() {
  if (!(await requireAdmin())) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const rows = await db.select().from(orders).orderBy(desc(orders.createdAt));
  // attach item counts
  const counts = await db
    .select({ orderId: orderItems.orderId, count: sql<number>`count(*)` })
    .from(orderItems)
    .groupBy(orderItems.orderId);
  const countMap = new Map(counts.map((c) => [c.orderId, Number(c.count)]));
  return NextResponse.json({
    orders: rows.map((o) => ({ ...o, itemCount: countMap.get(o.id) || 0 })),
  });
}
