import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/db";
import { orders, payments, storeSettings } from "@/db/schema";
import { and, eq } from "drizzle-orm";

const schema = z.object({
  orderNumber: z.string().min(1),
  phone: z.string().min(8),
  provider: z.enum(["bkash", "nagad"]),
  transactionId: z.string().min(3),
  senderPhone: z.string().min(8),
});

export async function POST(request: Request) {
  try {
    const data = schema.parse(await request.json());

    const [order] = await db.select().from(orders).where(eq(orders.orderNumber, data.orderNumber)).limit(1);
    if (!order || order.phone !== data.phone) {
      return NextResponse.json({ error: "Order not found" }, { status: 404 });
    }
    if (order.paymentStatus === "verified" || order.paymentStatus === "paid") {
      return NextResponse.json({ error: "Payment already verified" }, { status: 409 });
    }

    // prevent duplicate transaction id
    const [existingTxn] = await db
      .select()
      .from(payments)
      .where(and(eq(payments.provider, data.provider), eq(payments.transactionId, data.transactionId)))
      .limit(1);
    if (existingTxn) {
      return NextResponse.json({ error: "Duplicate transaction ID" }, { status: 409 });
    }

    const [settings] = await db.select().from(storeSettings).limit(1);
    // amount to pay = advance amount
    const amount = order.advanceAmount || 0;
    if (amount <= 0) {
      return NextResponse.json({ error: "No advance payment required" }, { status: 400 });
    }

    await db.insert(payments).values({
      orderId: order.id,
      provider: data.provider,
      accountType: data.provider === "bkash" ? settings?.bkashAccountType : settings?.nagadAccountType,
      amount,
      transactionId: data.transactionId,
      senderPhone: data.senderPhone,
      status: "pending_verification",
    });

    await db
      .update(orders)
      .set({
        paymentMethod: data.provider,
        paymentSubmittedAt: new Date(),
        updatedAt: new Date(),
      })
      .where(eq(orders.id, order.id));

    return NextResponse.json({ ok: true, orderNumber: order.orderNumber });
  } catch (error) {
    if (error instanceof z.ZodError) return NextResponse.json({ error: error.issues }, { status: 400 });
    console.error(error);
    return NextResponse.json({ error: "Payment submission failed" }, { status: 500 });
  }
}
