import { db } from "@/db";
import { products, productImages } from "@/db/schema";
import { eq, and, sql, desc, inArray } from "drizzle-orm";
import ProductCard from "@/components/ProductCard";

export const dynamic = "force-dynamic";

export default async function OffersPage() {
  const rows = await db.select().from(products).where(and(eq(products.isPublished, true), sql`${products.discountPrice} IS NOT NULL`)).orderBy(desc(products.createdAt));
  const ids = rows.map((r) => r.id);
  const imgs = ids.length ? await db.select().from(productImages).where(inArray(productImages.productId, ids)) : [];
  const map = new Map<string, string>();
  for (const img of imgs) if (!map.has(img.productId)) map.set(img.productId, img.url);
  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <h1 className="text-2xl font-bold">Offers</h1>
      <div className="mt-6 grid grid-cols-2 gap-4 md:grid-cols-4">
        {rows.map((p) => (
          <ProductCard key={p.id} product={{ ...p, imageUrl: map.get(p.id) || null }} />
        ))}
      </div>
    </div>
  );
}
