import { db } from "@/db";
import { products, productImages, categories, banners, reviews, users } from "@/db/schema";
import { eq, desc, and, inArray, sql } from "drizzle-orm";
import ProductCard from "@/components/ProductCard";
import Link from "next/link";

export const dynamic = "force-dynamic";

async function firstImages(productIds: string[]) {
  if (!productIds.length) return new Map<string, string>();
  const imgs = await db.select().from(productImages).where(inArray(productImages.productId, productIds));
  const map = new Map<string, string>();
  for (const img of imgs) if (!map.has(img.productId)) map.set(img.productId, img.url);
  return map;
}

export default async function HomePage() {
  const [bannerRows, categoryRows] = await Promise.all([
    db.select().from(banners).where(eq(banners.isActive, true)).orderBy(banners.sortOrder),
    db.select().from(categories).where(eq(categories.isActive, true)).orderBy(categories.sortOrder),
  ]);

  const featured = await db.select().from(products).where(and(eq(products.isPublished, true), eq(products.isFeatured, true))).orderBy(desc(products.createdAt)).limit(8);
  const latest = await db.select().from(products).where(eq(products.isPublished, true)).orderBy(desc(products.createdAt)).limit(8);
  const discounted = await db.select().from(products).where(and(eq(products.isPublished, true), sql`${products.discountPrice} IS NOT NULL`)).orderBy(desc(products.createdAt)).limit(8);
  const best = await db.select().from(products).where(and(eq(products.isPublished, true), eq(products.isBestSeller, true))).orderBy(desc(products.createdAt)).limit(8);

  const allIds = [...featured, ...latest, ...discounted, ...best].map((p) => p.id);
  const imageMap = await firstImages(allIds);

  const approvedReviews = await db
    .select()
    .from(reviews)
    .where(eq(reviews.isApproved, true))
    .orderBy(desc(reviews.createdAt))
    .limit(6);
  const userIds = [...new Set(approvedReviews.map((r) => r.userId))];
  const reviewUsers = userIds.length ? await db.select().from(users) : [];
  const userMap = new Map(reviewUsers.map((u) => [u.id, u.name]));

  const hero = bannerRows[0];

  return (
    <div>
      <section className="relative overflow-hidden bg-gradient-to-br from-red-600 to-red-800 text-white">
        <div className="mx-auto max-w-7xl px-4 py-16 md:py-24">
          {hero ? (
            <>
              <h1 className="text-3xl font-bold md:text-5xl">{hero.title}</h1>
              {hero.subtitle && <p className="mt-4 max-w-2xl text-lg text-red-100">{hero.subtitle}</p>}
              {hero.linkUrl && (
                <Link href={hero.linkUrl} className="mt-6 inline-block rounded-full bg-white px-6 py-3 font-semibold text-red-700">
                  Shop Now
                </Link>
              )}
            </>
          ) : (
            <>
              <h1 className="text-3xl font-bold md:text-5xl">Mariya Mobile Bazar</h1>
              <p className="mt-4 max-w-2xl text-lg text-red-100">
                Premium smartphones and accessories in Benapole, Jessore.
              </p>
              <Link href="/products" className="mt-6 inline-block rounded-full bg-white px-6 py-3 font-semibold text-red-700">
                Shop Now
              </Link>
            </>
          )}
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-8">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-bold">Smartphones</h2>
          <Link href="/products" className="text-sm font-semibold text-red-600">View all</Link>
        </div>
        <div className="mt-4 grid grid-cols-2 gap-4 md:grid-cols-4">
          {latest.map((p) => (
            <ProductCard key={p.id} product={{ ...p, color: (p as any).color, imageUrl: imageMap.get(p.id) || null }} />
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-10">
        <h2 className="text-xl font-bold">Categories</h2>
        <div className="mt-4 grid grid-cols-3 gap-3 md:grid-cols-7">
          {categoryRows.map((c) => (
            <Link
              key={c.id}
              href={`/products?category=${c.slug}`}
              className="rounded-2xl border border-gray-200 bg-white p-4 text-center text-sm font-semibold shadow-sm transition hover:border-red-300 hover:text-red-600"
            >
              {c.name}
            </Link>
          ))}
        </div>
      </section>

      {[
        { title: "Featured Products", items: featured },
        { title: "Latest Arrivals", items: latest },
        { title: "Discounted Products", items: discounted },
        { title: "Best Sellers", items: best },
      ].map((section) => (
        <section key={section.title} className="mx-auto max-w-7xl px-4 py-8">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold">{section.title}</h2>
            <Link href="/products" className="text-sm font-semibold text-red-600">
              View all
            </Link>
          </div>
          <div className="mt-4 grid grid-cols-2 gap-4 md:grid-cols-4">
            {section.items.map((p) => (
              <ProductCard
                key={p.id}
                product={{ ...p, imageUrl: imageMap.get(p.id) || null }}
              />
            ))}
          </div>
        </section>
      ))}

      <section className="mx-auto max-w-7xl px-4 py-10">
        <h2 className="text-xl font-bold">Customer Reviews</h2>
        <div className="mt-4 grid gap-4 md:grid-cols-3">
          {approvedReviews.length === 0 && (
            <p className="text-gray-500">No reviews yet.</p>
          )}
          {approvedReviews.map((r) => (
            <div key={r.id} className="rounded-2xl border border-gray-200 bg-white p-5 shadow-sm">
              <div className="text-yellow-500">{"★".repeat(r.rating)}</div>
              <p className="mt-2 text-sm text-gray-700">{r.comment}</p>
              <p className="mt-3 text-xs font-semibold text-gray-500">
                {userMap.get(r.userId) || "Customer"}
              </p>
            </div>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-10">
        <h2 className="text-xl font-bold">Frequently Asked Questions</h2>
        <div className="mt-4 space-y-3">
          {[
            { q: "How can I track my order?", a: "Use the Order Tracking page with your order number and phone number." },
            { q: "Is Cash on Delivery available?", a: "Yes, Cash on Delivery is available across Bangladesh." },
            { q: "What warranty do products have?", a: "Warranty details are listed on each product page." },
          ].map((faq) => (
            <details key={faq.q} className="rounded-2xl border border-gray-200 bg-white p-4">
              <summary className="cursor-pointer font-semibold">{faq.q}</summary>
              <p className="mt-2 text-sm text-gray-600">{faq.a}</p>
            </details>
          ))}
        </div>
      </section>
    </div>
  );
}
