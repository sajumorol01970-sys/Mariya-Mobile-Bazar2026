"use client";

import { useEffect, useState } from "react";
import Link from "next/link";

export default function AccountPage() {
  const [orders, setOrders] = useState<any[]>([]);
  const [wishlist, setWishlist] = useState<any[]>([]);
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    fetch("/api/auth/me").then((r) => r.json()).then((d) => setUser(d.user));
    fetch("/api/account/orders").then((r) => r.json()).then((d) => setOrders(d.orders || []));
    fetch("/api/wishlist").then((r) => r.json()).then((d) => setWishlist(d.products || []));
  }, []);

  async function logout() {
    await fetch("/api/auth/logout", { method: "POST" });
    window.location.href = "/";
  }

  return (
    <div className="mx-auto max-w-5xl px-4 py-8">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">My Account</h1>
        <button onClick={logout} className="rounded-full border border-gray-300 px-4 py-2 text-sm">Logout</button>
      </div>
      {user && <p className="mt-2 text-gray-600">{user.name} ({user.email})</p>}

      <section className="mt-8">
        <h2 className="text-xl font-bold">Order History</h2>
        <div className="mt-4 space-y-3">
          {orders.length === 0 && <p className="text-gray-500">No orders yet.</p>}
          {orders.map((o) => (
            <div key={o.id} className="rounded-2xl border border-gray-200 bg-white p-4">
              <p className="font-semibold">{o.orderNumber}</p>
              <p className="text-sm text-gray-600">Status: {o.status} | Total: {o.total} BDT</p>
              <Link href={`/track?orderNumber=${o.orderNumber}&phone=${o.phone}`} className="text-sm text-red-600">Track</Link>
            </div>
          ))}
        </div>
      </section>

      <section className="mt-8">
        <h2 className="text-xl font-bold">Wishlist</h2>
        <div className="mt-4 grid grid-cols-2 gap-4 md:grid-cols-4">
          {wishlist.map((p) => (
            <Link key={p.id} href={`/products/${p.slug}`} className="rounded-2xl border border-gray-200 bg-white p-3">
              <p className="text-sm font-semibold">{p.name}</p>
              <p className="text-sm font-bold">{p.discountPrice ?? p.price} BDT</p>
            </Link>
          ))}
        </div>
      </section>
    </div>
  );
}
