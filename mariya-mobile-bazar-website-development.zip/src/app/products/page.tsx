import { db } from "@/db";
import { products, productImages, categories } from "@/db/schema";
import { eq, and, desc, asc, ilike, or, sql, inArray } from "drizzle-orm";
import ProductCard from "@/components/ProductCard";
import Link from "next/link";

export const dynamic = "force-dynamic";

type SearchParams = { [key: string]: string | string[] | undefined };

export default async function ProductsPage({ searchParams }: { searchParams: Promise<SearchParams> }) {
  const sp = await searchParams;
  const q = typeof sp.q === "string" ? sp.q.trim() : "";
  const categorySlug = typeof sp.category === "string" ? sp.category : "";
  const brand = typeof sp.brand === "string" ? sp.brand : "";
  const sort = typeof sp.sort === "string" ? sp.sort : "newest";

  const conditions = [eq(products.isPublished, true)];
  if (q) {
    conditions.push(or(ilike(products.name, `%${q}%`), ilike(products.brand, `%${q}%`), ilike(products.model, `%${q}%`))!);
  }
  if (brand) conditions.push(eq(products.brand, brand));
  if (categorySlug) {
    const [cat] = await db.select().from(categories).where(eq(categories.slug, categorySlug)).limit(1);
    if (cat) conditions.push(eq(products.categoryId, cat.id));
  }

  const orderBy =
    sort === "price_asc"
      ? asc(products.discountPrice)
      : sort === "price_desc"
        ? desc(products.discountPrice)
        : sort === "name"
          ? asc(products.name)
          : desc(products.createdAt);

  const rows = await db.select().from(products).where(and(...conditions)).orderBy(orderBy).limit(48);
  const ids = rows.map((r) => r.id);
  const imgs = ids.length
    ? await db.select().from(productImages).where(sql`${productImages.productId} = ANY(${ids})`)
    : [];
  const imageMap = new Map<string, string>();
  for (const img of imgs) if (!imageMap.has(img.productId)) imageMap.set(img.productId, img.url);

  const categoryRows = await db.select().from(categories).where(eq(categories.isActive, true)).orderBy(categories.sortOrder);
  const brands = [...new Set(rows.map((r) => r.brand))];

  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <h1 className="text-2xl font-bold">Products</h1>

      <form className="mt-4 grid gap-3 rounded-2xl border border-gray-200 bg-gray-50 p-4 md:grid-cols-5">
        <input name="q" defaultValue={q} placeholder="Search..." className="rounded-lg border border-gray-300 px-3 py-2" />
        <select name="category" defaultValue={categorySlug} className="rounded-lg border border-gray-300 px-3 py-2">
          <option value="">All categories</option>
          {categoryRows.map((c) => (
            <option key={c.id} value={c.slug}>{c.name}</option>
          ))}
        </select>
        <select name="brand" defaultValue={brand} className="rounded-lg border border-gray-300 px-3 py-2">
          <option value="">All brands</option>
          {brands.map((b) => (
            <option key={b} value={b}>{b}</option>
          ))}
        </select>
        <select name="sort" defaultValue={sort} className="rounded-lg border border-gray-300 px-3 py-2">
          <option value="newest">Newest</option>
          <option value="price_asc">Price: Low to High</option>
          <option value="price_desc">Price: High to Low</option>
          <option value="name">Name</option>
        </select>
        <button className="rounded-lg bg-red-600 px-4 py-2 font-semibold text-white">Filter</button>
      </form>

      <div className="mt-6 grid grid-cols-2 gap-4 md:grid-cols-4">
        {rows.map((p) => (
          <ProductCard key={p.id} product={{ ...p, imageUrl: imageMap.get(p.id) || null }} />
        ))}
      </div>
      {rows.length === 0 && <p className="mt-8 text-center text-gray-500">No products found.</p>}
    </div>
  );
}
