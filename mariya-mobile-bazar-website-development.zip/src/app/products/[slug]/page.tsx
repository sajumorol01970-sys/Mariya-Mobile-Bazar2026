import { db } from "@/db";
import { products, productImages, categories, reviews, users } from "@/db/schema";
import { eq, and, ne, desc } from "drizzle-orm";
import { formatBDT, discountPercent } from "@/lib/utils";
import Link from "next/link";
import ProductActions from "@/components/ProductActions";

export const dynamic = "force-dynamic";

export default async function ProductDetailPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const [product] = await db.select().from(products).where(eq(products.slug, slug)).limit(1);
  if (!product || !product.isPublished) {
    return <div className="mx-auto max-w-7xl px-4 py-10">Product not found.</div>;
  }

  const images = await db.select().from(productImages).where(eq(productImages.productId, product.id)).orderBy(productImages.sortOrder);
  const [category] = product.categoryId
    ? await db.select().from(categories).where(eq(categories.id, product.categoryId)).limit(1)
    : [null];

  const relatedRows = product.categoryId
    ? await db.select().from(products).where(and(eq(products.isPublished, true), ne(products.id, product.id), eq(products.categoryId, product.categoryId))).limit(4)
    : await db.select().from(products).where(and(eq(products.isPublished, true), ne(products.id, product.id))).limit(4);

  const relatedImages = relatedRows.length
    ? await db.select().from(productImages).where(eq(productImages.productId, relatedRows[0].id))
    : [];
  // fetch all related images
  const relatedIds = relatedRows.map((r) => r.id);
  const relImgs = relatedIds.length
    ? await db.select().from(productImages).where(eq(productImages.productId, relatedIds[0]))
    : [];
  // simpler: query each
  const relImageMap = new Map<string, string>();
  for (const r of relatedRows) {
    const [img] = await db.select().from(productImages).where(eq(productImages.productId, r.id)).limit(1);
    if (img) relImageMap.set(r.id, img.url);
  }

  const approvedReviews = await db
    .select()
    .from(reviews)
    .where(and(eq(reviews.productId, product.id), eq(reviews.isApproved, true)))
    .orderBy(desc(reviews.createdAt));
  const reviewUsers = approvedReviews.length
    ? await db.select().from(users)
    : [];
  const userMap = new Map(reviewUsers.map((u) => [u.id, u.name]));

  const mainImage = images[0]?.url;
  const finalPrice = product.discountPrice ?? product.price;
  const percent = discountPercent(product.price, product.discountPrice);

  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <div className="grid gap-8 md:grid-cols-2">
        <div>
          <div className="aspect-square overflow-hidden rounded-2xl bg-gray-100">
            {mainImage ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={mainImage} alt={product.name} className="h-full w-full object-cover" />
            ) : (
              <div className="grid h-full place-items-center text-gray-400">No image</div>
            )}
          </div>
          {images.length > 1 && (
            <div className="mt-3 grid grid-cols-5 gap-2">
              {images.map((img) => (
                // eslint-disable-next-line @next/next/no-img-element
                <img key={img.id} src={img.url} alt={img.alt || product.name} className="aspect-square rounded-lg object-cover" />
              ))}
            </div>
          )}
        </div>

        <div>
          <p className="text-sm font-semibold uppercase text-red-600">{product.brand}</p>
          <h1 className="mt-1 text-2xl font-bold">{product.name}</h1>
          {category && <p className="mt-1 text-sm text-gray-500">Category: {category.name}</p>}

          <div className="mt-4 flex items-center gap-3">
            <span className="text-2xl font-bold">{formatBDT(finalPrice)}</span>
            {product.discountPrice && (
              <>
                <span className="text-gray-400 line-through">{formatBDT(product.price)}</span>
                <span className="rounded-full bg-red-100 px-2 py-0.5 text-xs font-semibold text-red-700">
                  -{percent}%
                </span>
              </>
            )}
          </div>

          <p className="mt-2 text-sm text-gray-600">
            {product.stock > 0 ? `Stock: ${product.stock}` : "Out of stock"}
          </p>

          <ProductActions product={{ id: product.id, name: product.name, slug: product.slug, price: product.price, discountPrice: product.discountPrice, stock: product.stock }} />

          <div className="mt-6 space-y-3 text-sm">
            {product.model && <p><strong>Model:</strong> {product.model}</p>}
            {product.ram && <p><strong>RAM:</strong> {product.ram}</p>}
            {product.storage && <p><strong>Storage:</strong> {product.storage}</p>}
            {product.color && <p><strong>Color:</strong> {product.color}</p>}
            <p><strong>Condition:</strong> {product.condition}</p>
            {product.warranty && <p><strong>Warranty:</strong> {product.warranty}</p>}
          </div>

          {product.description && (
            <div className="mt-6">
              <h2 className="font-semibold">Description</h2>
              <p className="mt-2 text-sm text-gray-700 whitespace-pre-line">{product.description}</p>
            </div>
          )}
          {product.specifications && (
            <div className="mt-4">
              <h2 className="font-semibold">Specifications</h2>
              <p className="mt-2 text-sm text-gray-700 whitespace-pre-line">{product.specifications}</p>
            </div>
          )}
        </div>
      </div>

      <section className="mt-12">
        <h2 className="text-xl font-bold">Related Products</h2>
        <div className="mt-4 grid grid-cols-2 gap-4 md:grid-cols-4">
          {relatedRows.map((p) => (
            <div key={p.id} className="overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-sm">
              <Link href={`/products/${p.slug}`}>
                <div className="aspect-square bg-gray-100">
                  {relImageMap.get(p.id) ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={relImageMap.get(p.id)!} alt={p.name} className="h-full w-full object-cover" />
                  ) : null}
                </div>
                <div className="p-3">
                  <p className="text-sm font-semibold">{p.name}</p>
                  <p className="text-sm font-bold">{formatBDT(p.discountPrice ?? p.price)}</p>
                </div>
              </Link>
            </div>
          ))}
        </div>
      </section>

      <section className="mt-12">
        <h2 className="text-xl font-bold">Reviews</h2>
        <div className="mt-4 space-y-3">
          {approvedReviews.length === 0 && <p className="text-gray-500">No reviews yet.</p>}
          {approvedReviews.map((r) => (
            <div key={r.id} className="rounded-2xl border border-gray-200 bg-white p-4">
              <div className="text-yellow-500">{"★".repeat(r.rating)}</div>
              <p className="mt-2 text-sm text-gray-700">{r.comment}</p>
              <p className="mt-2 text-xs text-gray-500">{userMap.get(r.userId) || "Customer"}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
