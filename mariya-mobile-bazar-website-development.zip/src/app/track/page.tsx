"use client";

import { useState } from "react";

export default function TrackPage() {
  const [orderNumber, setOrderNumber] = useState("");
  const [phone, setPhone] = useState("");
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState("");

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setResult(null);
    const res = await fetch(`/api/orders/track?orderNumber=${encodeURIComponent(orderNumber)}&phone=${encodeURIComponent(phone)}`);
    const data = await res.json();
    if (!res.ok) {
      setError(data.error || "Not found");
      return;
    }
    setResult(data);
  }

  return (
    <div className="mx-auto max-w-2xl px-4 py-8">
      <h1 className="text-2xl font-bold">Track Order</h1>
      <form onSubmit={submit} className="mt-6 space-y-4 rounded-2xl border border-gray-200 bg-white p-6">
        <input required placeholder="Order number" value={orderNumber} onChange={(e) => setOrderNumber(e.target.value)} className="w-full rounded-lg border border-gray-300 px-3 py-2" />
        <input required placeholder="Phone number" value={phone} onChange={(e) => setPhone(e.target.value)} className="w-full rounded-lg border border-gray-300 px-3 py-2" />
        <button className="w-full rounded-full bg-red-600 py-3 font-semibold text-white">Track</button>
      </form>
      {error && <p className="mt-4 text-red-600">{error}</p>}
      {result && (
        <div className="mt-6 rounded-2xl border border-gray-200 bg-white p-6">
          <p><strong>Order:</strong> {result.order.orderNumber}</p>
          <p><strong>Status:</strong> {result.order.status}</p>
          <p><strong>Total:</strong> {result.order.total} BDT</p>
          <p><strong>Delivery:</strong> {result.order.deliveryCharge} BDT</p>
          <ul className="mt-4 space-y-2 text-sm">
            {result.items.map((i: any) => (
              <li key={i.id}>{i.productName} × {i.quantity} = {i.lineTotal} BDT</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
