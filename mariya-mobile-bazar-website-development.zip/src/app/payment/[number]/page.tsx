"use client";

import { Suspense, useEffect, useState } from "react";
import { useParams, useSearchParams, useRouter } from "next/navigation";

function PaymentInner() {
  const params = useParams();
  const sp = useSearchParams();
  const router = useRouter();
  const number = params.number as string;
  const phone = sp.get("phone") || "";

  const [order, setOrder] = useState<any>(null);
  const [items, setItems] = useState<any[]>([]);
  const [settings, setSettings] = useState<any>(null);
  const [provider, setProvider] = useState<"bkash" | "nagad">("bkash");
  const [transactionId, setTransactionId] = useState("");
  const [senderPhone, setSenderPhone] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  useEffect(() => {
    if (!phone) return;
    fetch(`/api/orders/track?orderNumber=${encodeURIComponent(number)}&phone=${encodeURIComponent(phone)}`)
      .then((r) => r.json())
      .then((d) => {
        if (d.order) {
          setOrder(d.order);
          setItems(d.items || []);
        }
      });
    fetch("/api/settings").then((r) => r.json()).then(setSettings);
  }, [number, phone]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    const res = await fetch("/api/payments", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ orderNumber: number, phone, provider, transactionId, senderPhone }),
    });
    const data = await res.json();
    if (!res.ok) {
      setError(data.error || "Failed");
      return;
    }
    setSuccess("Payment details submitted. Verification pending.");
  }

  if (!order) return <div className="p-8">Loading order...</div>;

  const paymentAmount = order.advanceAmount || 0;

  return (
    <div className="mx-auto max-w-2xl px-4 py-8">
      <h1 className="text-2xl font-bold">Payment</h1>
      <div className="mt-4 rounded-2xl border border-gray-200 bg-white p-4 text-sm">
        <p><strong>Order:</strong> {order.orderNumber}</p>
        <p><strong>Amount to pay:</strong> {paymentAmount} BDT</p>
        <p><strong>Remaining balance:</strong> {order.remainingAmount} BDT (pay on delivery)</p>
      </div>

      <div className="mt-4 flex gap-2">
        <button onClick={() => setProvider("bkash")} className={`rounded-full px-4 py-2 ${provider === "bkash" ? "bg-pink-600 text-white" : "border"}`}>bKash</button>
        <button onClick={() => setProvider("nagad")} className={`rounded-full px-4 py-2 ${provider === "nagad" ? "bg-orange-600 text-white" : "border"}`}>Nagad</button>
      </div>

      <div className="mt-4 rounded-2xl border border-gray-200 bg-gray-50 p-4 text-sm">
        {provider === "bkash" ? (
          <>
            <p><strong>bKash {settings?.bkashAccountType || "personal"} account:</strong> {settings?.bkashNumber || "Not configured"}</p>
            <p className="mt-2">{settings?.bkashInstructions || "Use Send Money to the number above. Do not use payment without verifying."}</p>
          </>
        ) : (
          <>
            <p><strong>Nagad {settings?.nagadAccountType || "personal"} account:</strong> {settings?.nagadNumber || "Not configured"}</p>
            <p className="mt-2">{settings?.nagadInstructions || "Use Send Money to the number above."}</p>
          </>
        )}
        <p className="mt-2 text-xs text-gray-500">
          Manual payment is not automatically verified. The admin will verify using payment provider records.
        </p>
      </div>

      <form onSubmit={submit} className="mt-6 space-y-4 rounded-2xl border border-gray-200 bg-white p-6">
        <input required placeholder="Transaction ID" value={transactionId} onChange={(e) => setTransactionId(e.target.value)} className="w-full rounded-lg border border-gray-300 px-3 py-2" />
        <input required placeholder="Sender payment phone number" value={senderPhone} onChange={(e) => setSenderPhone(e.target.value)} className="w-full rounded-lg border border-gray-300 px-3 py-2" />
        {error && <p className="text-sm text-red-600">{error}</p>}
        {success && <p className="text-sm text-green-600">{success}</p>}
        <button className="w-full rounded-full bg-red-600 py-3 font-semibold text-white">পেমেন্ট তথ্য জমা দিন</button>
      </form>
    </div>
  );
}

export default function PaymentPage() {
  return (
    <Suspense fallback={<div className="p-8">Loading...</div>}>
      <PaymentInner />
    </Suspense>
  );
}
