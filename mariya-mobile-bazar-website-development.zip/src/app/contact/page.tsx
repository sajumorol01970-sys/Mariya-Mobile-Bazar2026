export default function ContactPage() {
  return (
    <div className="mx-auto max-w-3xl px-4 py-8">
      <h1 className="text-2xl font-bold">Contact</h1>
      <p className="mt-4">Mariya Mobile Bazar</p>
      <p>Benapole, Jessore, Bangladesh</p>
      <p>Phone: +8801700000000</p>
      <p>Email: info@mariyamobilebazar.com</p>
    </div>
  );
}